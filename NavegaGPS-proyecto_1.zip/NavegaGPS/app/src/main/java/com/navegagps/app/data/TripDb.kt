package com.navegagps.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Base de datos local (SQLite). Todo el historial vive en el teléfono:
 * ni un dato de recorrido sale del dispositivo.
 */
class TripDb(context: Context) : SQLiteOpenHelper(context.applicationContext, NAME, null, VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE trips (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at INTEGER NOT NULL,
                ended_at INTEGER NOT NULL DEFAULT 0,
                origin_name TEXT NOT NULL DEFAULT '',
                dest_name TEXT NOT NULL DEFAULT '',
                dest_lat REAL NOT NULL DEFAULT 0,
                dest_lng REAL NOT NULL DEFAULT 0,
                distance_m REAL NOT NULL DEFAULT 0,
                total_s REAL NOT NULL DEFAULT 0,
                moving_s REAL NOT NULL DEFAULT 0,
                stop_count INTEGER NOT NULL DEFAULT 0,
                max_speed REAL NOT NULL DEFAULT 0,
                avg_speed REAL NOT NULL DEFAULT 0,
                finished INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trip_id INTEGER NOT NULL,
                lat REAL NOT NULL,
                lng REAL NOT NULL,
                t INTEGER NOT NULL,
                speed REAL NOT NULL DEFAULT 0,
                accuracy REAL NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_points_trip ON points(trip_id, t)")
        db.execSQL(
            """
            CREATE TABLE stops (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trip_id INTEGER NOT NULL,
                lat REAL NOT NULL,
                lng REAL NOT NULL,
                start_t INTEGER NOT NULL,
                end_t INTEGER NOT NULL,
                label TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_stops_trip ON stops(trip_id)")
        db.execSQL(
            """
            CREATE TABLE favorites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                address TEXT NOT NULL DEFAULT '',
                lat REAL NOT NULL,
                lng REAL NOT NULL,
                created_at INTEGER NOT NULL,
                kind TEXT NOT NULL DEFAULT 'fav'
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Versión 1: no hay migraciones todavía.
    }

    companion object {
        const val NAME = "navegagps.db"
        const val VERSION = 1

        fun values(vararg pairs: Pair<String, Any?>): ContentValues {
            val cv = ContentValues()
            for ((k, v) in pairs) {
                when (v) {
                    null -> cv.putNull(k)
                    is Int -> cv.put(k, v)
                    is Long -> cv.put(k, v)
                    is Double -> cv.put(k, v)
                    is Float -> cv.put(k, v)
                    is Boolean -> cv.put(k, if (v) 1 else 0)
                    else -> cv.put(k, v.toString())
                }
            }
            return cv
        }
    }
}
