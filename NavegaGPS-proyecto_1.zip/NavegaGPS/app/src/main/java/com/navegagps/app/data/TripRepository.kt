package com.navegagps.app.data

import android.content.Context
import android.database.Cursor
import com.navegagps.app.core.Geo
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.nav.Place
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Acceso al historial de trayectos y a los destinos guardados. */
class TripRepository(context: Context) {

    private val helper = TripDb(context)

    // ---------- trayectos ----------

    suspend fun createTrip(originName: String, destName: String, dest: GeoPoint?): Long =
        withContext(Dispatchers.IO) {
            helper.writableDatabase.insert(
                "trips", null,
                TripDb.values(
                    "started_at" to System.currentTimeMillis(),
                    "origin_name" to originName,
                    "dest_name" to destName,
                    "dest_lat" to (dest?.lat ?: 0.0),
                    "dest_lng" to (dest?.lng ?: 0.0)
                )
            )
        }

    suspend fun addPoint(tripId: Long, p: TrackPoint) = withContext(Dispatchers.IO) {
        helper.writableDatabase.insert(
            "points", null,
            TripDb.values(
                "trip_id" to tripId,
                "lat" to p.lat,
                "lng" to p.lng,
                "t" to p.time,
                "speed" to p.speed,
                "accuracy" to p.accuracy
            )
        )
        Unit
    }

    suspend fun addStop(tripId: Long, stop: TripStop) = withContext(Dispatchers.IO) {
        helper.writableDatabase.insert(
            "stops", null,
            TripDb.values(
                "trip_id" to tripId,
                "lat" to stop.lat,
                "lng" to stop.lng,
                "start_t" to stop.startTime,
                "end_t" to stop.endTime,
                "label" to stop.label
            )
        )
        Unit
    }

    /** Cierra el trayecto y recalcula sus totales a partir de los puntos guardados. */
    suspend fun finishTrip(tripId: Long): Trip? = withContext(Dispatchers.IO) {
        val db = helper.writableDatabase
        val points = readPoints(tripId)
        var distance = 0.0
        var moving = 0.0
        var maxSpeed = 0.0
        for (i in 1 until points.size) {
            val a = points[i - 1]
            val b = points[i]
            val d = Geo.distance(a.toGeo(), b.toGeo())
            val dt = (b.time - a.time) / 1000.0
            if (dt in 0.1..120.0 && d < 400.0) {
                distance += d
                val v = d / dt
                if (v > 0.7) moving += dt
                if (v > maxSpeed && v < 70.0) maxSpeed = v
            }
            if (b.speed > maxSpeed && b.speed < 70f) maxSpeed = b.speed.toDouble()
        }
        val started = points.firstOrNull()?.time
            ?: cursorLong(db.rawQuery("SELECT started_at FROM trips WHERE id=?", arrayOf("$tripId")))
        val ended = points.lastOrNull()?.time ?: System.currentTimeMillis()
        val total = ((ended - started) / 1000.0).coerceAtLeast(0.0)
        val stops = cursorLong(
            db.rawQuery("SELECT COUNT(*) FROM stops WHERE trip_id=?", arrayOf("$tripId"))
        ).toInt()

        db.update(
            "trips",
            TripDb.values(
                "ended_at" to ended,
                "distance_m" to distance,
                "total_s" to total,
                "moving_s" to moving,
                "stop_count" to stops,
                "max_speed" to maxSpeed,
                "avg_speed" to if (total > 0) distance / total else 0.0,
                "finished" to true
            ),
            "id=?", arrayOf("$tripId")
        )
        getTrip(tripId)
    }

    suspend fun deleteTrip(tripId: Long) = withContext(Dispatchers.IO) {
        val db = helper.writableDatabase
        db.delete("points", "trip_id=?", arrayOf("$tripId"))
        db.delete("stops", "trip_id=?", arrayOf("$tripId"))
        db.delete("trips", "id=?", arrayOf("$tripId"))
        Unit
    }

    /** Borra trayectos vacíos (por ejemplo, si la navegación se canceló enseguida). */
    suspend fun pruneEmpty() = withContext(Dispatchers.IO) {
        val db = helper.writableDatabase
        db.execSQL(
            "DELETE FROM trips WHERE distance_m < 80 AND id NOT IN (SELECT trip_id FROM points GROUP BY trip_id HAVING COUNT(*) > 20)"
        )
        Unit
    }

    suspend fun listTrips(limit: Int = 300): List<Trip> = withContext(Dispatchers.IO) {
        val c = helper.readableDatabase.rawQuery(
            "SELECT * FROM trips WHERE finished=1 ORDER BY started_at DESC LIMIT $limit", null
        )
        val out = ArrayList<Trip>()
        c.use { while (it.moveToNext()) out.add(readTrip(it)) }
        out
    }

    suspend fun getTrip(id: Long): Trip? = withContext(Dispatchers.IO) {
        val c = helper.readableDatabase.rawQuery("SELECT * FROM trips WHERE id=?", arrayOf("$id"))
        c.use { if (it.moveToFirst()) readTrip(it) else null }
    }

    suspend fun detail(id: Long): TripDetail? = withContext(Dispatchers.IO) {
        val trip = getTrip(id) ?: return@withContext null
        TripDetail(trip, readPoints(id), readStops(id))
    }

    suspend fun totals(): TripTotals = withContext(Dispatchers.IO) {
        val c = helper.readableDatabase.rawQuery(
            "SELECT COUNT(*), IFNULL(SUM(distance_m),0), IFNULL(SUM(total_s),0), IFNULL(SUM(moving_s),0), IFNULL(SUM(stop_count),0) FROM trips WHERE finished=1",
            null
        )
        c.use {
            if (it.moveToFirst()) {
                TripTotals(it.getInt(0), it.getDouble(1), it.getDouble(2), it.getDouble(3), it.getInt(4))
            } else TripTotals(0, 0.0, 0.0, 0.0, 0)
        }
    }

    private fun readPoints(tripId: Long): List<TrackPoint> {
        val c = helper.readableDatabase.rawQuery(
            "SELECT lat,lng,t,speed,accuracy FROM points WHERE trip_id=? ORDER BY t ASC",
            arrayOf("$tripId")
        )
        val out = ArrayList<TrackPoint>()
        c.use {
            while (it.moveToNext()) {
                out.add(TrackPoint(it.getDouble(0), it.getDouble(1), it.getLong(2), it.getFloat(3), it.getFloat(4)))
            }
        }
        return out
    }

    private fun readStops(tripId: Long): List<TripStop> {
        val c = helper.readableDatabase.rawQuery(
            "SELECT id,lat,lng,start_t,end_t,label FROM stops WHERE trip_id=? ORDER BY start_t ASC",
            arrayOf("$tripId")
        )
        val out = ArrayList<TripStop>()
        c.use {
            while (it.moveToNext()) {
                out.add(TripStop(it.getLong(0), it.getDouble(1), it.getDouble(2), it.getLong(3), it.getLong(4), it.getString(5) ?: ""))
            }
        }
        return out
    }

    private fun readTrip(c: Cursor): Trip = Trip(
        id = c.getLong(c.getColumnIndexOrThrow("id")),
        startedAt = c.getLong(c.getColumnIndexOrThrow("started_at")),
        endedAt = c.getLong(c.getColumnIndexOrThrow("ended_at")),
        originName = c.getString(c.getColumnIndexOrThrow("origin_name")) ?: "",
        destName = c.getString(c.getColumnIndexOrThrow("dest_name")) ?: "",
        destLat = c.getDouble(c.getColumnIndexOrThrow("dest_lat")),
        destLng = c.getDouble(c.getColumnIndexOrThrow("dest_lng")),
        distanceMeters = c.getDouble(c.getColumnIndexOrThrow("distance_m")),
        totalSeconds = c.getDouble(c.getColumnIndexOrThrow("total_s")),
        movingSeconds = c.getDouble(c.getColumnIndexOrThrow("moving_s")),
        stopCount = c.getInt(c.getColumnIndexOrThrow("stop_count")),
        maxSpeed = c.getDouble(c.getColumnIndexOrThrow("max_speed")),
        avgSpeed = c.getDouble(c.getColumnIndexOrThrow("avg_speed"))
    )

    private fun cursorLong(c: Cursor): Long = c.use { if (it.moveToFirst()) it.getLong(0) else 0L }

    // ---------- favoritos y recientes ----------

    suspend fun saveFavorite(place: Place, kind: String = "fav") = withContext(Dispatchers.IO) {
        val db = helper.writableDatabase
        db.delete("favorites", "kind=? AND ABS(lat-?)<0.0004 AND ABS(lng-?)<0.0004",
            arrayOf(kind, "${place.point.lat}", "${place.point.lng}"))
        db.insert(
            "favorites", null,
            TripDb.values(
                "name" to place.name,
                "address" to place.address,
                "lat" to place.point.lat,
                "lng" to place.point.lng,
                "created_at" to System.currentTimeMillis(),
                "kind" to kind
            )
        )
        if (kind == "recent") {
            db.execSQL(
                "DELETE FROM favorites WHERE kind='recent' AND id NOT IN (SELECT id FROM favorites WHERE kind='recent' ORDER BY created_at DESC LIMIT 15)"
            )
        }
        Unit
    }

    suspend fun favorites(kind: String = "fav", limit: Int = 30): List<Place> =
        withContext(Dispatchers.IO) {
            val c = helper.readableDatabase.rawQuery(
                "SELECT name,address,lat,lng FROM favorites WHERE kind=? ORDER BY created_at DESC LIMIT $limit",
                arrayOf(kind)
            )
            val out = ArrayList<Place>()
            c.use {
                while (it.moveToNext()) {
                    out.add(Place(it.getString(0) ?: "", it.getString(1) ?: "", GeoPoint(it.getDouble(2), it.getDouble(3))))
                }
            }
            out
        }

    suspend fun deleteFavorite(place: Place) = withContext(Dispatchers.IO) {
        helper.writableDatabase.delete(
            "favorites", "ABS(lat-?)<0.0004 AND ABS(lng-?)<0.0004",
            arrayOf("${place.point.lat}", "${place.point.lng}")
        )
        Unit
    }

    // ---------- exportación ----------

    suspend fun exportGpx(tripId: Long): String = withContext(Dispatchers.IO) {
        val d = detail(tripId) ?: return@withContext ""
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        iso.timeZone = TimeZone.getTimeZone("UTC")
        buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
            append("<gpx version=\"1.1\" creator=\"NavegaGPS\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
            append("  <metadata><name>").append(escape(d.trip.destName.ifBlank { "Trayecto" }))
            append("</name><time>").append(iso.format(Date(d.trip.startedAt))).append("</time></metadata>\n")
            for (s in d.stops) {
                append("  <wpt lat=\"").append(s.lat).append("\" lon=\"").append(s.lng).append("\">")
                append("<name>Parada ").append(escape(s.label)).append("</name>")
                append("<time>").append(iso.format(Date(s.startTime))).append("</time></wpt>\n")
            }
            append("  <trk><name>").append(escape(d.trip.destName.ifBlank { "Trayecto" })).append("</name><trkseg>\n")
            for (p in d.points) {
                append("    <trkpt lat=\"").append(p.lat).append("\" lon=\"").append(p.lng).append("\">")
                append("<time>").append(iso.format(Date(p.time))).append("</time>")
                append("<speed>").append(p.speed).append("</speed></trkpt>\n")
            }
            append("  </trkseg></trk>\n</gpx>\n")
        }
    }

    suspend fun exportCsv(tripId: Long): String = withContext(Dispatchers.IO) {
        val d = detail(tripId) ?: return@withContext ""
        buildString {
            append("tiempo_iso,lat,lng,velocidad_kmh,precision_m\n")
            val iso = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            for (p in d.points) {
                append(iso.format(Date(p.time))).append(",")
                append(p.lat).append(",").append(p.lng).append(",")
                append(String.format(Locale.US, "%.1f", p.speed * 3.6f)).append(",")
                append(String.format(Locale.US, "%.0f", p.accuracy)).append("\n")
            }
        }
    }

    private fun escape(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
}
