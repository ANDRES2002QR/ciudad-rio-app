package com.navegagps.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.activity.compose.BackHandler
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.location.NavigationService
import com.navegagps.app.nav.Phase
import com.navegagps.app.nav.Place
import com.navegagps.app.ui.HistoryScreen
import com.navegagps.app.ui.MainViewModel
import com.navegagps.app.ui.MapScreen
import com.navegagps.app.ui.NavegaTheme
import com.navegagps.app.ui.Screen
import com.navegagps.app.ui.SearchScreen
import com.navegagps.app.ui.SettingsScreen
import com.navegagps.app.ui.TripDetailScreen

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            vm.controller.startLocationUpdates()
        } else {
            vm.showMessage("Sin permiso de ubicación la app no puede navegar.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            NavegaTheme {
                AppRoot(vm)
            }
        }

        requestPermissions()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (vm.prefs.keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        vm.controller.startLocationUpdates()
    }

    private fun requestPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    /** Soporta enlaces geo:lat,lng de otras apps. */
    private fun handleIntent(intent: Intent?) {
        val data: Uri = intent?.data ?: return
        if (data.scheme != "geo") return
        val raw = data.schemeSpecificPart ?: return
        val coords = raw.substringBefore("?").split(",")
        if (coords.size < 2) return
        val lat = coords[0].toDoubleOrNull() ?: return
        val lng = coords[1].toDoubleOrNull() ?: return
        val label = data.getQueryParameter("q") ?: "Destino compartido"
        vm.controller.setDestination(Place(label, "", GeoPoint(lat, lng)))
    }
}

@Composable
private fun AppRoot(vm: MainViewModel) {
    val ui by vm.ui.collectAsState()
    val nav by vm.navState.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val context = androidx.compose.ui.platform.LocalContext.current

    // El servicio en primer plano sigue vivo mientras haya navegación o grabación.
    LaunchedEffect(nav.phase, nav.recordingTripId) {
        if (nav.phase == Phase.NAVIGATING || nav.recordingTripId != null) {
            NavigationService.start(context)
        } else {
            NavigationService.stop(context)
        }
    }

    LaunchedEffect(ui.message, nav.error, nav.info) {
        val msg = ui.message ?: nav.error ?: nav.info
        if (!msg.isNullOrBlank()) {
            snackbar.showSnackbar(msg)
            vm.showMessage(null)
            vm.controller.clearError()
        }
    }

    BackHandler(enabled = ui.screen != Screen.MAPA) {
        when (ui.screen) {
            Screen.DETALLE -> vm.closeTrip()
            else -> vm.go(Screen.MAPA)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) }
    ) { _ ->
        Box(Modifier.fillMaxSize()) {
            when (ui.screen) {
                Screen.MAPA -> MapScreen(vm)
                Screen.BUSCAR -> SearchScreen(vm)
                Screen.HISTORIAL -> HistoryScreen(vm)
                Screen.DETALLE -> TripDetailScreen(vm)
                Screen.AJUSTES -> SettingsScreen(vm)
            }
        }
    }
}
