package com.navegagps.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navegagps.app.core.Format
import com.navegagps.app.data.Trip

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val ui by vm.ui.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .padding(top = 28.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.go(Screen.MAPA) }) {
                Icon(ManeuverIcons.back, contentDescription = "Volver")
            }
            Text("Historial de trayectos", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        Spacer(Modifier.height(6.dp))
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Metric("Trayectos", "${ui.totals.trips}")
                Metric("Distancia", Format.distanceLong(ui.totals.distanceMeters))
                Metric("Al volante", Format.duration(ui.totals.movingSeconds))
                Metric("Paradas", "${ui.totals.stops}")
            }
        }
        Spacer(Modifier.height(10.dp))

        if (ui.trips.isEmpty()) {
            Text(
                "Todavía no hay trayectos guardados. Inicia una ruta o pulsa «Grabar» para registrar un recorrido.",
                color = GrisTexto,
                fontSize = 13.sp,
                modifier = Modifier.padding(12.dp)
            )
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(ui.trips) { trip ->
                TripRow(trip) { vm.openTrip(trip.id) }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(label, fontSize = 11.sp, color = GrisTexto)
    }
}

@Composable
private fun TripRow(trip: Trip, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
        ) {
            Icon(
                Icons.Filled.Route, null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(10.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(trip.destName.ifBlank { "Recorrido" }, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(Format.dateTime(trip.startedAt), fontSize = 11.sp, color = GrisTexto)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(Format.distanceLong(trip.distanceMeters), fontWeight = FontWeight.SemiBold)
            Text(Format.duration(trip.totalSeconds), fontSize = 11.sp, color = GrisTexto)
        }
    }
}
