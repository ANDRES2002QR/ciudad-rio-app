package com.navegagps.app.nav

import com.navegagps.app.core.GeoPoint

/** Un carril de una intersección, tal como lo entrega OSRM. */
data class LaneInfo(
    val valid: Boolean,
    val active: Boolean,
    val indications: List<String>
)

data class Maneuver(
    val type: String,
    val modifier: String?,
    val location: GeoPoint,
    val bearingBefore: Int,
    val bearingAfter: Int,
    val exit: Int?
)

data class RouteStep(
    val name: String,
    val ref: String?,
    val distance: Double,
    val duration: Double,
    val maneuver: Maneuver,
    val lanes: List<LaneInfo>,
    val geometry: List<GeoPoint>,
    val instruction: String,
    val voice: String,
    /** distancia acumulada desde el inicio de la ruta hasta el INICIO de este paso */
    var startDistance: Double = 0.0
)

/** Nivel de congestión estimado o real de un tramo. */
enum class Congestion { DESCONOCIDO, FLUIDO, MODERADO, LENTO, DETENIDO }

data class TrafficSegment(
    val fromIndex: Int,
    val toIndex: Int,
    val level: Congestion
)

data class NavRoute(
    val id: String,
    val label: String,
    val distance: Double,
    val duration: Double,
    val points: List<GeoPoint>,
    val steps: List<RouteStep>,
    /** velocidad (m/s) por segmento de la geometría, tamaño = points.size - 1 */
    val segmentSpeeds: DoubleArray,
    val summary: String,
    val traffic: List<TrafficSegment> = emptyList(),
    val hasTolls: Boolean = false
) {
    val cumulative: DoubleArray by lazy { com.navegagps.app.core.Geo.cumulative(points) }

    fun withTraffic(t: List<TrafficSegment>) = copy(traffic = t)

    /** Duración ajustada por el tráfico conocido (si hay). */
    fun effectiveDuration(): Double {
        if (traffic.isEmpty() || duration <= 0.0 || distance <= 0.0) return duration
        var extra = 0.0
        for (seg in traffic) {
            val len = (cumulative.getOrElse(seg.toIndex) { 0.0 } - cumulative.getOrElse(seg.fromIndex) { 0.0 })
            val penalty = when (seg.level) {
                Congestion.MODERADO -> 0.25
                Congestion.LENTO -> 0.7
                Congestion.DETENIDO -> 1.6
                else -> 0.0
            }
            val base = duration * (if (distance > 0) len / distance else 0.0)
            extra += base * penalty
        }
        return duration + extra
    }

    override fun equals(other: Any?): Boolean = other is NavRoute && other.id == id
    override fun hashCode(): Int = id.hashCode()
}

/** Un destino elegido por el usuario. */
data class Place(
    val name: String,
    val address: String,
    val point: GeoPoint
)
