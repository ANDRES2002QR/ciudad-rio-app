package com.navegagps.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.navegagps.app.NavegaApp
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.data.Trip
import com.navegagps.app.data.TripDetail
import com.navegagps.app.data.TripTotals
import com.navegagps.app.nav.Place
import com.navegagps.app.net.NominatimClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

enum class Screen { MAPA, BUSCAR, HISTORIAL, DETALLE, AJUSTES }

data class UiState(
    val screen: Screen = Screen.MAPA,
    val query: String = "",
    val searching: Boolean = false,
    val results: List<Place> = emptyList(),
    val favorites: List<Place> = emptyList(),
    val recents: List<Place> = emptyList(),
    val trips: List<Trip> = emptyList(),
    val totals: TripTotals = TripTotals(0, 0.0, 0.0, 0.0, 0),
    val detail: TripDetail? = null,
    val followCamera: Boolean = true,
    val message: String? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val appRef = app as NavegaApp
    val controller = appRef.controller
    val prefs = appRef.prefs
    private val repo = appRef.repository

    val navState = controller.state

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var searchJob: Job? = null

    init {
        refreshPlaces()
        refreshHistory()
    }

    // ------------------------------------------------------------ navegación UI

    fun go(screen: Screen) {
        _ui.value = _ui.value.copy(screen = screen)
        if (screen == Screen.HISTORIAL) refreshHistory()
        if (screen == Screen.BUSCAR) refreshPlaces()
    }

    fun setFollow(follow: Boolean) {
        _ui.value = _ui.value.copy(followCamera = follow)
    }

    fun showMessage(text: String?) {
        _ui.value = _ui.value.copy(message = text)
    }

    // ---------------------------------------------------------------- búsqueda

    fun onQueryChange(q: String) {
        _ui.value = _ui.value.copy(query = q)
        searchJob?.cancel()
        if (q.trim().length < 3) {
            _ui.value = _ui.value.copy(results = emptyList(), searching = false)
            return
        }
        searchJob = viewModelScope.launch {
            delay(450) // antirrebote: no golpear el servidor en cada tecla
            _ui.value = _ui.value.copy(searching = true)
            val near = controller.state.value.fix?.point
            val res = runCatching { NominatimClient.search(q, near) }.getOrElse { emptyList() }
            _ui.value = _ui.value.copy(results = res, searching = false)
        }
    }

    fun chooseDestination(place: Place) {
        viewModelScope.launch { repo.saveFavorite(place, "recent") }
        controller.setDestination(place)
        _ui.value = _ui.value.copy(screen = Screen.MAPA, query = "", results = emptyList())
        refreshPlaces()
    }

    fun chooseFromMap(point: GeoPoint) {
        controller.setDestinationFromMap(point)
        _ui.value = _ui.value.copy(screen = Screen.MAPA)
    }

    fun saveFavorite(place: Place) {
        viewModelScope.launch {
            repo.saveFavorite(place, "fav")
            refreshPlaces()
            showMessage("Guardado en favoritos")
        }
    }

    fun deleteFavorite(place: Place) {
        viewModelScope.launch {
            repo.deleteFavorite(place)
            refreshPlaces()
        }
    }

    private fun refreshPlaces() {
        viewModelScope.launch {
            _ui.value = _ui.value.copy(
                favorites = repo.favorites("fav"),
                recents = repo.favorites("recent", 10)
            )
        }
    }

    // ---------------------------------------------------------------- historial

    fun refreshHistory() {
        viewModelScope.launch {
            _ui.value = _ui.value.copy(trips = repo.listTrips(), totals = repo.totals())
        }
    }

    fun openTrip(id: Long) {
        viewModelScope.launch {
            val d = repo.detail(id)
            _ui.value = _ui.value.copy(detail = d, screen = Screen.DETALLE)
        }
    }

    fun closeTrip() {
        _ui.value = _ui.value.copy(detail = null, screen = Screen.HISTORIAL)
    }

    fun deleteTrip(id: Long) {
        viewModelScope.launch {
            repo.deleteTrip(id)
            _ui.value = _ui.value.copy(detail = null, screen = Screen.HISTORIAL)
            refreshHistory()
            showMessage("Trayecto eliminado")
        }
    }

    /** Exporta el trayecto y abre el diálogo de compartir de Android. */
    fun exportTrip(context: Context, id: Long, gpx: Boolean) {
        viewModelScope.launch {
            val content = if (gpx) repo.exportGpx(id) else repo.exportCsv(id)
            if (content.isBlank()) {
                showMessage("No hay puntos para exportar")
                return@launch
            }
            val dir = File(context.cacheDir, "exports").apply { mkdirs() }
            val file = File(dir, "trayecto-$id." + if (gpx) "gpx" else "csv")
            file.writeText(content)
            val uri = FileProvider.getUriForFile(
                context, context.packageName + ".fileprovider", file
            )
            val send = Intent(Intent.ACTION_SEND).apply {
                type = if (gpx) "application/gpx+xml" else "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, "Compartir trayecto"))
        }
    }

    override fun onCleared() {
        super.onCleared()
    }
}
