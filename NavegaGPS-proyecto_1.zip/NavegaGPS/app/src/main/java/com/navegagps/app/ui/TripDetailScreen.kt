package com.navegagps.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navegagps.app.core.Format
import com.navegagps.app.core.Geo
import com.navegagps.app.map.MapRenderer

@Composable
fun TripDetailScreen(vm: MainViewModel) {
    val ui by vm.ui.collectAsState()
    val detail = ui.detail
    val context = LocalContext.current
    val dark = isSystemInDarkTheme()
    var renderer by remember { mutableStateOf<MapRenderer?>(null) }

    if (detail == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Sin datos") }
        return
    }
    val trip = detail.trip
    val track = detail.points.map { it.toGeo() }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(top = 26.dp, start = 4.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.closeTrip() }) {
                Icon(ManeuverIcons.back, contentDescription = "Volver")
            }
            Column(Modifier.weight(1f)) {
                Text(trip.destName.ifBlank { "Recorrido" }, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(Format.dateTime(trip.startedAt), fontSize = 11.sp, color = GrisTexto)
            }
            IconButton(onClick = { vm.deleteTrip(trip.id) }) {
                Icon(Icons.Filled.Delete, contentDescription = "Eliminar", tint = Rojo)
            }
        }

        Box(Modifier.fillMaxWidth().height(260.dp)) {
            MapCanvas(
                modifier = Modifier.fillMaxSize(),
                styleUrl = if (dark) MapRenderer.STYLE_NIGHT else MapRenderer.STYLE_DAY,
                onReady = { _, r -> renderer = r },
                onTap = { _, _ -> },
                onLongTap = { },
                onUserGesture = { }
            )
            LaunchedEffect(renderer, detail.trip.id) {
                val r = renderer ?: return@LaunchedEffect
                val simplified = Geo.simplify(track, 6.0)
                r.setTrack(simplified)
                r.setMarkers(
                    destination = track.lastOrNull(),
                    waypoints = detail.stops.map { com.navegagps.app.core.GeoPoint(it.lat, it.lng) }
                )
                r.fit(simplified, paddingPx = 60, extraBottomPx = 60)
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("Distancia", Format.distanceLong(trip.distanceMeters))
                        Stat("Duración total", Format.durationPrecise(trip.totalSeconds))
                        Stat("En movimiento", Format.durationPrecise(trip.movingSeconds))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("Detenido", Format.durationPrecise(trip.stoppedSeconds))
                        Stat("Vel. media", Format.speedKmh(trip.avgMovingSpeed))
                        Stat("Vel. máxima", Format.speedKmh(trip.maxSpeed))
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("Paradas (${detail.stops.size})", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            if (detail.stops.isEmpty()) {
                Text("No se registraron paradas de más de 45 segundos.", fontSize = 13.sp, color = GrisTexto)
            } else {
                detail.stops.forEach { stop ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Parada ${stop.label}", fontWeight = FontWeight.Medium)
                            Text(Format.dateTime(stop.startTime), fontSize = 11.sp, color = GrisTexto)
                        }
                        Text(Format.duration(stop.durationSec), fontWeight = FontWeight.SemiBold)
                    }
                    HorizontalDivider()
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { vm.exportTrip(context, trip.id, gpx = true) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Download, null)
                    Spacer(Modifier.height(0.dp))
                    Text(" GPX")
                }
                OutlinedButton(
                    onClick = { vm.exportTrip(context, trip.id, gpx = false) },
                    modifier = Modifier.weight(1f)
                ) { Text("CSV") }
                OutlinedButton(
                    onClick = { vm.deleteTrip(trip.id) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Rojo)
                ) { Text("Borrar") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(label, fontSize = 11.sp, color = GrisTexto)
    }
}
