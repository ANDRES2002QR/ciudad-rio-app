package com.navegagps.app.core

import android.content.Context
import android.content.SharedPreferences

/**
 * Preferencias de la app. Todo lo que el usuario puede controlar del comportamiento
 * de rutas, voz y tráfico vive aquí.
 */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.getSharedPreferences("navegagps", Context.MODE_PRIVATE)

    /** Si true, la app cambia sola a la mejor ruta. Si false, solo avisa y decide el usuario. */
    var autoSwitchRoutes: Boolean
        get() = sp.getBoolean("auto_switch", false)
        set(v) = sp.edit().putBoolean("auto_switch", v).apply()

    /** Ahorro mínimo (en minutos) para proponer o aplicar un cambio de ruta. */
    var minGainMinutes: Int
        get() = sp.getInt("min_gain_min", 3)
        set(v) = sp.edit().putInt("min_gain_min", v).apply()

    /** Cada cuántos segundos se buscan rutas alternativas mientras se conduce. */
    var alternativesIntervalSec: Int
        get() = sp.getInt("alt_interval", 90)
        set(v) = sp.edit().putInt("alt_interval", v).apply()

    var voiceEnabled: Boolean
        get() = sp.getBoolean("voice", true)
        set(v) = sp.edit().putBoolean("voice", v).apply()

    var showOnewayArrows: Boolean
        get() = sp.getBoolean("oneway", true)
        set(v) = sp.edit().putBoolean("oneway", v).apply()

    var showTraffic: Boolean
        get() = sp.getBoolean("traffic", true)
        set(v) = sp.edit().putBoolean("traffic", v).apply()

    var showSpeedLimits: Boolean
        get() = sp.getBoolean("speed_limits", true)
        set(v) = sp.edit().putBoolean("speed_limits", v).apply()

    var avoidTolls: Boolean
        get() = sp.getBoolean("avoid_tolls", false)
        set(v) = sp.edit().putBoolean("avoid_tolls", v).apply()

    var recordTrips: Boolean
        get() = sp.getBoolean("record_trips", true)
        set(v) = sp.edit().putBoolean("record_trips", v).apply()

    var keepScreenOn: Boolean
        get() = sp.getBoolean("keep_screen", true)
        set(v) = sp.edit().putBoolean("keep_screen", v).apply()

    var northUp: Boolean
        get() = sp.getBoolean("north_up", false)
        set(v) = sp.edit().putBoolean("north_up", v).apply()

    /** Clave opcional de TomTom para tráfico en tiempo real. Vacío = tráfico estimado. */
    var tomtomKey: String
        get() = sp.getString("tomtom_key", "") ?: ""
        set(v) = sp.edit().putString("tomtom_key", v).apply()

    /** URL del servidor de ruteo OSRM (puedes apuntar a uno propio). */
    var osrmBase: String
        get() = sp.getString("osrm_base", "https://router.project-osrm.org") ?: "https://router.project-osrm.org"
        set(v) = sp.edit().putString("osrm_base", v).apply()

    var simulateDriving: Boolean
        get() = sp.getBoolean("simulate", false)
        set(v) = sp.edit().putBoolean("simulate", v).apply()
}
