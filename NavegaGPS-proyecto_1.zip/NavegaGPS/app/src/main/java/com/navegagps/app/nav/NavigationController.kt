package com.navegagps.app.nav

import android.content.Context
import com.navegagps.app.core.Format
import com.navegagps.app.core.Geo
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.core.Prefs
import com.navegagps.app.data.TrackPoint
import com.navegagps.app.data.TripRepository
import com.navegagps.app.data.TripStop
import com.navegagps.app.location.Fix
import com.navegagps.app.location.LocationEngine
import com.navegagps.app.net.NominatimClient
import com.navegagps.app.net.OsrmClient
import com.navegagps.app.net.OverpassClient
import com.navegagps.app.net.TrafficProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

enum class Phase { IDLE, PREVIEW, NAVIGATING }

data class NavProgress(
    val onRoute: Boolean,
    val snapped: GeoPoint,
    val distanceAlong: Double,
    val remainingDistance: Double,
    val remainingDuration: Double,
    val stepIndex: Int,
    val distanceToManeuver: Double,
    val currentStep: RouteStep?,
    val nextStep: RouteStep?,
    val lanes: List<LaneInfo>,
    val speedLimitKmh: Int?,
    val speedKmh: Int,
    val overspeed: Boolean,
    val etaMillis: Long
)

/** Propuesta de cambio de ruta mientras se conduce. */
data class RouteSuggestion(
    val route: NavRoute,
    val gainSeconds: Double
)

data class NavState(
    val phase: Phase = Phase.IDLE,
    val fix: Fix? = null,
    val destination: Place? = null,
    val routes: List<NavRoute> = emptyList(),
    val activeRouteId: String? = null,
    val progress: NavProgress? = null,
    val suggestion: RouteSuggestion? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val info: String? = null,
    val trafficLive: Boolean = false,
    val recordingTripId: Long? = null,
    val recalculating: Boolean = false,
    val lastAlternativesAt: Long = 0L
) {
    val activeRoute: NavRoute? get() = routes.firstOrNull { it.id == activeRouteId } ?: routes.firstOrNull()
    val alternatives: List<NavRoute> get() = routes.filter { it.id != activeRoute?.id }
}

/**
 * Cerebro de la navegación: ubicación, ruta activa, alternativas en vivo,
 * instrucciones, voz y grabación del trayecto.
 *
 * Regla de oro pedida por el usuario: la app NUNCA cambia de ruta por su cuenta
 * salvo que el "cambio automático" esté activado en ajustes. Por defecto solo
 * propone, y el conductor decide con un toque (o ignora y sigue igual).
 */
class NavigationController(
    private val context: Context,
    val prefs: Prefs,
    private val repo: TripRepository
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val engine = LocationEngine(context)
    private val osrm = OsrmClient { prefs.osrmBase }
    val voice = Voice(context)

    private val _state = MutableStateFlow(NavState())
    val state: StateFlow<NavState> = _state.asStateFlow()

    private var locationJob: Job? = null
    private var altJob: Job? = null
    private var simJob: Job? = null

    private var roadIndex: OverpassClient.RoadIndex? = null
    private var lastProjIndex = 0
    private var offRouteHits = 0
    private val spoken = HashSet<String>()

    // grabación
    private var lastRecordedPoint: TrackPoint? = null
    private var stopStartedAt: Long = 0L
    private var stopPoint: GeoPoint? = null
    private var stopCounter = 0

    // ---------------------------------------------------------------- ubicación

    fun startLocationUpdates() {
        if (locationJob != null) return
        voice.enabled = prefs.voiceEnabled
        val job = scope.launch {
            engine.updates(1000L).collect { fix ->
                if (!prefs.simulateDriving || _state.value.phase != Phase.NAVIGATING) {
                    onFix(fix)
                }
            }
        }
        job.invokeOnCompletion { locationJob = null }
        locationJob = job
    }

    fun stopLocationUpdates() {
        locationJob?.cancel()
        locationJob = null
    }

    private fun onFix(fix: Fix) {
        val st = _state.value
        _state.value = st.copy(fix = fix)
        if (st.phase == Phase.NAVIGATING) {
            updateProgress(fix)
        }
        recordFix(fix)
    }

    // ------------------------------------------------------------------ destino

    fun clearError() {
        _state.value = _state.value.copy(error = null, info = null)
    }

    fun setDestination(place: Place) {
        _state.value = _state.value.copy(destination = place, error = null)
        planRoutes()
    }

    fun setDestinationFromMap(point: GeoPoint) {
        scope.launch {
            _state.value = _state.value.copy(loading = true)
            val place = runCatching { NominatimClient.reverse(point) }
                .getOrElse { Place("Punto en el mapa", "", point) }
            _state.value = _state.value.copy(destination = place, loading = false)
            planRoutes()
        }
    }

    /** Calcula (o recalcula) las rutas posibles hacia el destino elegido. */
    fun planRoutes() {
        val dest = _state.value.destination ?: return
        val from = _state.value.fix?.point
        if (from == null) {
            _state.value = _state.value.copy(error = "Todavía no tengo tu ubicación. Activa el GPS y espera unos segundos.")
            return
        }
        scope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val routes = osrm.route(listOf(from, dest.point), alternatives = 3)
                if (routes.isEmpty()) {
                    _state.value = _state.value.copy(loading = false, error = "No se encontraron rutas.")
                    return@launch
                }
                val enriched = enrich(routes)
                _state.value = _state.value.copy(
                    phase = Phase.PREVIEW,
                    routes = enriched.first,
                    activeRouteId = enriched.first.first().id,
                    trafficLive = enriched.second,
                    loading = false
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "No se pudo calcular la ruta."
                )
            }
        }
    }

    /** Añade tráfico y atributos de vía (límites de velocidad) a las rutas. */
    private suspend fun enrich(routes: List<NavRoute>): Pair<List<NavRoute>, Boolean> {
        val main = routes.first()
        val roads = if (prefs.showSpeedLimits || prefs.showTraffic) {
            runCatching { OverpassClient.roadsAlong(main.points) }.getOrNull()
        } else null
        if (roads != null) roadIndex = roads

        if (!prefs.showTraffic) return routes to false

        var live = false
        val out = routes.map { r ->
            val res = runCatching { TrafficProvider.forRoute(r, roads, prefs.tomtomKey) }.getOrNull()
            if (res != null) {
                if (res.live) live = true
                r.withTraffic(res.segments)
            } else r
        }
        return out to live
    }

    /** El usuario elige otra de las rutas mostradas (antes o durante el viaje). */
    fun selectRoute(routeId: String) {
        val st = _state.value
        val route = st.routes.firstOrNull { it.id == routeId } ?: return
        lastProjIndex = 0
        offRouteHits = 0
        spoken.clear()
        _state.value = st.copy(activeRouteId = routeId, suggestion = null)
        if (st.phase == Phase.NAVIGATING) {
            voice.speak("Cambiando a ${route.label}. ${Format.duration(route.duration)} hasta el destino.", urgent = true)
            st.fix?.let { updateProgress(it) }
        }
        scope.launch {
            runCatching { roadIndex = OverpassClient.roadsAlong(route.points) }
        }
    }

    fun cancelPreview() {
        _state.value = _state.value.copy(phase = Phase.IDLE, routes = emptyList(), activeRouteId = null, destination = null)
    }

    // --------------------------------------------------------------- navegación

    fun startNavigation() {
        val st = _state.value
        val route = st.activeRoute ?: return
        lastProjIndex = 0
        offRouteHits = 0
        spoken.clear()
        stopCounter = 0
        stopPoint = null
        lastRecordedPoint = null

        _state.value = st.copy(phase = Phase.NAVIGATING, suggestion = null, error = null)
        voice.enabled = prefs.voiceEnabled
        voice.speak(
            "Iniciando ${route.label} hacia ${st.destination?.name ?: "el destino"}. " +
                "${Format.distance(route.distance)}, ${Format.duration(route.duration)}.",
            urgent = true
        )

        if (prefs.recordTrips) {
            scope.launch {
                val id = repo.createTrip(
                    originName = "Origen",
                    destName = st.destination?.name ?: "Destino",
                    dest = st.destination?.point
                )
                _state.value = _state.value.copy(recordingTripId = id)
            }
        }

        startAlternativesLoop()
        if (prefs.simulateDriving) startSimulation()
        _state.value.fix?.let { updateProgress(it) }
    }

    fun stopNavigation(arrived: Boolean = false) {
        altJob?.cancel(); altJob = null
        simJob?.cancel(); simJob = null
        val tripId = _state.value.recordingTripId
        if (tripId != null) {
            scope.launch {
                closeOpenStop(tripId)
                repo.finishTrip(tripId)
                repo.pruneEmpty()
            }
        }
        if (arrived) voice.speak("Has llegado a tu destino.", urgent = true) else voice.stop()
        _state.value = _state.value.copy(
            phase = Phase.IDLE,
            routes = emptyList(),
            activeRouteId = null,
            progress = null,
            suggestion = null,
            recordingTripId = null,
            info = if (arrived) "Llegaste a tu destino." else null
        )
    }

    private fun updateProgress(fix: Fix) {
        val st = _state.value
        val route = st.activeRoute ?: return
        val pts = route.points
        if (pts.size < 2) return

        // Map-matching: se busca en una ventana hacia adelante para no "saltar"
        // a un tramo de la ruta que aún no se ha recorrido.
        var pr = Geo.project(pts, fix.point, lastProjIndex, 80)
        if (pr.offsetMeters > 60) {
            val global = Geo.project(pts, fix.point, 0, -1)
            if (global.offsetMeters < pr.offsetMeters) pr = global
        }
        lastProjIndex = max(0, pr.index - 2)

        val onRoute = pr.offsetMeters <= 45.0
        if (!onRoute) offRouteHits++ else offRouteHits = 0

        val along = Geo.distanceAlong(pts, route.cumulative, pr)
        val remainingDistance = max(0.0, route.distance - along)

        var stepIndex = 0
        for (i in route.steps.indices) {
            val s = route.steps[i]
            if (along >= s.startDistance - 1.0) stepIndex = i else break
        }
        val current = route.steps.getOrNull(stepIndex)
        val next = route.steps.getOrNull(stepIndex + 1)
        val endOfStep = (current?.startDistance ?: 0.0) + (current?.distance ?: 0.0)
        val toManeuver = max(0.0, endOfStep - along)

        var remainingDuration = 0.0
        for (i in stepIndex + 1 until route.steps.size) remainingDuration += route.steps[i].duration
        current?.let {
            val frac = if (it.distance > 0) (toManeuver / it.distance) else 0.0
            remainingDuration += it.duration * Geo.clamp(frac, 0.0, 1.0)
        }
        if (route.traffic.isNotEmpty() && route.duration > 0.0 && route.distance > 0.0) {
            remainingDuration *= (route.effectiveDuration() / route.duration)
        }

        val limit = if (prefs.showSpeedLimits) roadIndex?.nearest(pr.point, 30.0)?.maxSpeedKmh else null
        val speedKmh = (fix.speed * 3.6f).toInt()

        val progress = NavProgress(
            onRoute = onRoute,
            snapped = if (onRoute) pr.point else fix.point,
            distanceAlong = along,
            remainingDistance = remainingDistance,
            remainingDuration = remainingDuration,
            stepIndex = stepIndex,
            distanceToManeuver = toManeuver,
            currentStep = current,
            nextStep = next,
            lanes = next?.lanes ?: emptyList(),
            speedLimitKmh = limit,
            speedKmh = speedKmh,
            overspeed = limit != null && speedKmh > limit + 5,
            etaMillis = System.currentTimeMillis() + (remainingDuration * 1000).toLong()
        )
        _state.value = _state.value.copy(progress = progress)

        announce(progress, fix)

        if (remainingDistance < 25.0) {
            stopNavigation(arrived = true)
            return
        }
        if (offRouteHits >= 3 && !_state.value.recalculating) recalculate()
    }

    private fun announce(p: NavProgress, fix: Fix) {
        if (!prefs.voiceEnabled) return
        val next = p.nextStep ?: return
        val key = "${p.stepIndex}"
        val speed = max(fix.speed.toDouble(), 5.0)
        val farThreshold = Geo.clamp(speed * 25.0, 350.0, 1200.0)
        val nearThreshold = Geo.clamp(speed * 10.0, 150.0, 400.0)

        val base = next.instruction
        when {
            p.distanceToManeuver <= 45 && spoken.add("$key-now") ->
                voice.speak(base, urgent = true)
            p.distanceToManeuver <= nearThreshold && spoken.add("$key-near") ->
                voice.speak(Instructions.spoken(base, p.distanceToManeuver))
            p.distanceToManeuver <= farThreshold && spoken.add("$key-far") ->
                voice.speak(Instructions.spoken(base, p.distanceToManeuver))
        }
        // aviso de carriles cuando existen y la maniobra está cerca
        if (p.lanes.isNotEmpty() && p.distanceToManeuver <= nearThreshold && spoken.add("$key-lane")) {
            val valid = p.lanes.count { it.valid }
            if (valid in 1..3 && p.lanes.size > valid) {
                voice.speak("Ubícate en ${if (valid == 1) "el carril indicado" else "los $valid carriles indicados"}.")
            }
        }
    }

    /** Recalcula la ruta cuando el conductor se salió del trazado. */
    fun recalculate() {
        val st = _state.value
        val dest = st.destination ?: return
        val from = st.fix?.point ?: return
        if (st.recalculating) return
        _state.value = st.copy(recalculating = true)
        voice.speak("Recalculando la ruta.", urgent = true)
        scope.launch {
            try {
                val routes = osrm.route(listOf(from, dest.point), alternatives = 3)
                if (routes.isNotEmpty()) {
                    val enriched = enrich(routes)
                    lastProjIndex = 0
                    offRouteHits = 0
                    spoken.clear()
                    _state.value = _state.value.copy(
                        routes = enriched.first,
                        activeRouteId = enriched.first.first().id,
                        trafficLive = enriched.second,
                        recalculating = false
                    )
                } else {
                    _state.value = _state.value.copy(recalculating = false)
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(recalculating = false)
            }
        }
    }

    // ----------------------------------------------- alternativas mientras se conduce

    private fun startAlternativesLoop() {
        altJob?.cancel()
        altJob = scope.launch {
            while (isActive) {
                delay(prefs.alternativesIntervalSec.coerceIn(30, 600) * 1000L)
                val st = _state.value
                if (st.phase != Phase.NAVIGATING) continue
                val dest = st.destination ?: continue
                val from = st.fix?.point ?: continue
                val current = st.activeRoute ?: continue
                val remaining = st.progress?.remainingDuration ?: current.duration
                try {
                    val fresh = osrm.route(listOf(from, dest.point), alternatives = 3)
                    if (fresh.isEmpty()) continue
                    val enriched = enrich(fresh).first

                    // Se conserva la ruta activa en la lista para poder volver a ella.
                    val merged = ArrayList<NavRoute>()
                    merged.add(current)
                    var n = 1
                    for (r in enriched) {
                        if (r.points.size < 2) continue
                        if (isSameRoute(r, current)) continue
                        merged.add(r.copy(id = "alt-$n-${System.currentTimeMillis()}", label = "Alterna $n"))
                        n++
                    }

                    val best = merged.drop(1).minByOrNull { it.effectiveDuration() }
                    val gain = if (best != null) remaining - best.effectiveDuration() else 0.0
                    val minGain = prefs.minGainMinutes * 60.0

                    _state.value = _state.value.copy(
                        routes = merged,
                        activeRouteId = current.id,
                        lastAlternativesAt = System.currentTimeMillis(),
                        suggestion = if (best != null && gain >= minGain) RouteSuggestion(best, gain) else null
                    )

                    if (best != null && gain >= minGain) {
                        if (prefs.autoSwitchRoutes) {
                            selectRoute(best.id)
                            voice.speak(
                                "Cambio automático de ruta: ahorras ${Format.duration(gain)}.",
                                urgent = true
                            )
                        } else {
                            voice.speak(
                                "Hay otra ruta ${Format.duration(gain)} más rápida. " +
                                    "Puedes cambiarla en pantalla o seguir por la actual."
                            )
                        }
                    }
                } catch (e: Exception) {
                    // Sin conexión: se sigue con la ruta actual, sin molestar al conductor.
                }
            }
        }
    }

    fun acceptSuggestion() {
        _state.value.suggestion?.let { selectRoute(it.route.id) }
    }

    fun dismissSuggestion() {
        _state.value = _state.value.copy(suggestion = null)
    }

    /** Pide alternativas ahora mismo (botón "buscar otra ruta"). */
    fun refreshAlternativesNow() {
        val st = _state.value
        val dest = st.destination ?: return
        val from = st.fix?.point ?: return
        scope.launch {
            _state.value = _state.value.copy(loading = true)
            try {
                val fresh = enrich(osrm.route(listOf(from, dest.point), alternatives = 3)).first
                val current = if (st.phase == Phase.NAVIGATING) st.activeRoute else null
                val merged = ArrayList<NavRoute>()
                if (current != null) merged.add(current)
                var n = 1
                for (r in fresh) {
                    if (r.points.size < 2) continue
                    if (current != null && isSameRoute(r, current)) continue
                    merged.add(
                        r.copy(
                            id = "opt-$n-${System.currentTimeMillis()}",
                            label = if (current != null) "Alterna $n" else "Ruta $n"
                        )
                    )
                    n++
                }
                _state.value = _state.value.copy(
                    routes = merged,
                    activeRouteId = current?.id ?: merged.firstOrNull()?.id,
                    loading = false,
                    info = if (merged.size <= 1) "No hay otras rutas distintas por ahora." else "Se actualizaron las rutas disponibles."
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, error = "No se pudieron buscar alternativas.")
            }
        }
    }

    /** Dos rutas se consideran la misma si coinciden en longitud y en el punto medio. */
    private fun isSameRoute(a: NavRoute, b: NavRoute): Boolean {
        if (a.points.isEmpty() || b.points.isEmpty()) return false
        val ma = a.points[a.points.size / 2]
        val mb = b.points[b.points.size / 2]
        val similarLength = kotlin.math.abs(a.distance - b.distance) < b.distance * 0.04
        return similarLength && Geo.distance(ma, mb) < 80.0
    }

    // ------------------------------------------------------------- grabación

    private fun recordFix(fix: Fix) {
        val tripId = _state.value.recordingTripId ?: return
        val last = lastRecordedPoint
        val moved = last == null || Geo.distance(GeoPoint(last.lat, last.lng), fix.point) >= 8.0
        val timePassed = last == null || (fix.time - last.time) >= 4000

        if (moved || timePassed) {
            val tp = TrackPoint(fix.point.lat, fix.point.lng, fix.time, fix.speed, fix.accuracy)
            lastRecordedPoint = tp
            scope.launch { repo.addPoint(tripId, tp) }
        }

        // Detección de paradas: menos de 1 m/s durante 45 s seguidos.
        if (fix.speed < 1.0f) {
            if (stopStartedAt == 0L) {
                stopStartedAt = fix.time
                stopPoint = fix.point
            }
        } else if (fix.speed > 2.5f) {
            val started = stopStartedAt
            val p = stopPoint
            if (started != 0L && p != null && fix.time - started >= 45_000) {
                stopCounter++
                val stop = TripStop(0, p.lat, p.lng, started, fix.time, "$stopCounter")
                scope.launch { repo.addStop(tripId, stop) }
            }
            stopStartedAt = 0L
            stopPoint = null
        }
    }

    private suspend fun closeOpenStop(tripId: Long) {
        val started = stopStartedAt
        val p = stopPoint
        val now = System.currentTimeMillis()
        if (started != 0L && p != null && now - started >= 45_000) {
            stopCounter++
            repo.addStop(tripId, TripStop(0, p.lat, p.lng, started, now, "$stopCounter"))
        }
        stopStartedAt = 0L
        stopPoint = null
    }

    /** Grabar un recorrido sin destino fijado. */
    fun startFreeRecording() {
        if (_state.value.recordingTripId != null) return
        scope.launch {
            val id = repo.createTrip("Origen", "Recorrido libre", null)
            _state.value = _state.value.copy(recordingTripId = id, info = "Grabando recorrido.")
        }
    }

    fun stopFreeRecording() {
        val id = _state.value.recordingTripId ?: return
        scope.launch {
            closeOpenStop(id)
            repo.finishTrip(id)
            _state.value = _state.value.copy(recordingTripId = null, info = "Recorrido guardado en el historial.")
        }
    }

    // ------------------------------------------------------------- simulación

    /** Recorre la ruta activa sin moverse: sirve para probar la app en casa. */
    private fun startSimulation() {
        simJob?.cancel()
        simJob = scope.launch {
            val route = _state.value.activeRoute ?: return@launch
            var traveled = 0.0
            val total = route.distance
            while (isActive && traveled < total && _state.value.phase == Phase.NAVIGATING) {
                val limit = roadIndex?.nearest(Geo.interpolate(route.points, traveled), 30.0)?.maxSpeedKmh
                val speed = ((limit ?: 50) / 3.6) * 0.85
                traveled += speed
                val p = Geo.interpolate(route.points, traveled)
                val ahead = Geo.interpolate(route.points, min(total, traveled + 15.0))
                onFix(
                    Fix(
                        point = p,
                        accuracy = 5f,
                        speed = speed.toFloat(),
                        bearing = Geo.bearing(p, ahead).toFloat(),
                        hasBearing = true,
                        time = System.currentTimeMillis(),
                        simulated = true
                    )
                )
                delay(1000)
            }
        }
    }

    fun shutdown() {
        stopLocationUpdates()
        altJob?.cancel()
        simJob?.cancel()
        voice.shutdown()
    }
}
