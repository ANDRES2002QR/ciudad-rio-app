package com.navegagps.app.net

import android.net.Uri
import com.navegagps.app.core.Geo
import com.navegagps.app.core.GeoPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

/**
 * Consulta a Overpass (OpenStreetMap) los atributos de las vías por donde pasa la
 * ruta: límite de velocidad, sentido único y número de carriles.
 * Se hace UNA vez por ruta y se guarda en memoria.
 */
object OverpassClient {

    private const val ENDPOINT = "https://overpass-api.de/api/interpreter"

    data class WayInfo(
        val maxSpeedKmh: Int?,
        val oneway: Boolean,
        val lanes: Int?,
        val name: String?,
        val geometry: List<GeoPoint>
    )

    class RoadIndex(private val ways: List<WayInfo>) {

        private val bounds: List<DoubleArray> = ways.map { Geo.bbox(it.geometry) }

        /** Devuelve la vía más cercana al punto dentro de [toleranceMeters]. */
        fun nearest(point: GeoPoint, toleranceMeters: Double = 25.0): WayInfo? {
            var best: WayInfo? = null
            var bestD = toleranceMeters
            for (i in ways.indices) {
                val w = ways[i]
                if (w.geometry.size < 2) continue
                val bb = bounds[i]
                if (point.lat < bb[0] - 0.003 || point.lat > bb[2] + 0.003 ||
                    point.lng < bb[1] - 0.003 || point.lng > bb[3] + 0.003
                ) continue
                val pr = Geo.project(w.geometry, point)
                if (pr.offsetMeters < bestD) {
                    bestD = pr.offsetMeters
                    best = w
                }
            }
            return best
        }

        val size: Int get() = ways.size
    }

    /** Descarga los atributos de las vías dentro del corredor de la ruta. */
    suspend fun roadsAlong(route: List<GeoPoint>): RoadIndex = withContext(Dispatchers.IO) {
        if (route.isEmpty()) return@withContext RoadIndex(emptyList())
        val bb = Geo.bbox(route)
        // margen de ~250 m
        val pad = 0.0025
        val query = String.format(
            Locale.US,
            "[out:json][timeout:25];way[\"highway\"~\"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link)$\"](%.5f,%.5f,%.5f,%.5f);out tags geom;",
            bb[0] - pad, bb[1] - pad, bb[2] + pad, bb[3] + pad
        )
        val url = "$ENDPOINT?data=" + Uri.encode(query)
        val json = JSONObject(Http.getString(url))
        val elements = json.optJSONArray("elements") ?: return@withContext RoadIndex(emptyList())
        val ways = ArrayList<WayInfo>(elements.length())
        for (i in 0 until elements.length()) {
            val el = elements.getJSONObject(i)
            if (el.optString("type") != "way") continue
            val geomJson = el.optJSONArray("geometry") ?: continue
            val geom = ArrayList<GeoPoint>(geomJson.length())
            for (k in 0 until geomJson.length()) {
                val g = geomJson.getJSONObject(k)
                geom.add(GeoPoint(g.optDouble("lat"), g.optDouble("lon")))
            }
            val tags = el.optJSONObject("tags") ?: JSONObject()
            ways.add(
                WayInfo(
                    maxSpeedKmh = parseMaxSpeed(tags.optString("maxspeed", "")),
                    oneway = tags.optString("oneway", "no").let { it == "yes" || it == "1" || it == "-1" },
                    lanes = tags.optString("lanes", "").toIntOrNull(),
                    name = tags.optString("name", "").ifBlank { null },
                    geometry = geom
                )
            )
        }
        RoadIndex(ways)
    }

    /** "50", "50 km/h", "30 mph", "RO:urban" -> km/h */
    fun parseMaxSpeed(raw: String): Int? {
        if (raw.isBlank()) return null
        val s = raw.trim().lowercase(Locale.US)
        val num = Regex("\\d+").find(s)?.value?.toIntOrNull() ?: return null
        return if (s.contains("mph")) (num * 1.60934).toInt() else num
    }
}
