package com.navegagps.app.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.navegagps.app.core.GeoPoint
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlin.math.abs

/** Una lectura de posición ya filtrada. */
data class Fix(
    val point: GeoPoint,
    val accuracy: Float,
    val speed: Float,
    val bearing: Float,
    val hasBearing: Boolean,
    val time: Long,
    val simulated: Boolean = false
)

/**
 * Posición del teléfono con la mayor precisión posible:
 * - Fused Location a 1 Hz con prioridad alta (usa GPS + Wi-Fi + sensores).
 * - Respaldo al GPS puro si no hay Google Play Services.
 * - Filtro de Kalman en 1D sobre la posición para quitar el "salto" típico
 *   y descarte de lecturas con precisión peor que 50 m cuando ya hay una buena.
 */
class LocationEngine(private val context: Context) {

    private val kalman = KalmanLatLng()

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun updates(intervalMs: Long = 1000L): Flow<Fix> = callbackFlow {
        if (!hasPermission()) {
            close()
            return@callbackFlow
        }

        var fused: FusedLocationProviderClient? = null
        var fusedCallback: LocationCallback? = null
        var lm: LocationManager? = null
        var lmListener: LocationListener? = null

        val emit: (Location) -> Unit = { loc ->
            val f = filter(loc)
            if (f != null) trySend(f)
        }

        val playAvailable = try {
            Class.forName("com.google.android.gms.location.LocationServices")
            true
        } catch (e: Throwable) {
            false
        }

        if (playAvailable) {
            try {
                val client = LocationServices.getFusedLocationProviderClient(context)
                val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMs)
                    .setMinUpdateIntervalMillis(intervalMs / 2)
                    .setWaitForAccurateLocation(false)
                    .setMinUpdateDistanceMeters(0f)
                    .build()
                val cb = object : LocationCallback() {
                    override fun onLocationResult(result: LocationResult) {
                        result.lastLocation?.let(emit)
                    }
                }
                client.requestLocationUpdates(req, cb, Looper.getMainLooper())
                client.lastLocation.addOnSuccessListener { l -> l?.let(emit) }
                fused = client
                fusedCallback = cb
            } catch (e: Throwable) {
                fused = null
            }
        }

        if (fused == null) {
            val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) = emit(location)
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            try {
                manager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, intervalMs, 0f, listener, Looper.getMainLooper()
                )
                if (manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    manager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER, intervalMs * 3, 0f, listener,
                        Looper.getMainLooper()
                    )
                }
            } catch (e: SecurityException) {
                close(e)
            }
            lm = manager
            lmListener = listener
        }

        awaitClose {
            fusedCallback?.let { cb -> fused?.removeLocationUpdates(cb) }
            lmListener?.let { l -> lm?.removeUpdates(l) }
        }
    }

    private var lastGood: Location? = null

    private fun filter(loc: Location): Fix? {
        if (loc.latitude == 0.0 && loc.longitude == 0.0) return null
        val acc = if (loc.hasAccuracy()) loc.accuracy else 30f

        // Rechaza saltos imposibles (> 55 m/s respecto a la última buena lectura).
        val prev = lastGood
        if (prev != null) {
            val dt = (loc.time - prev.time) / 1000.0
            if (dt in 0.2..30.0) {
                val d = prev.distanceTo(loc)
                if (d / dt > 55.0 && acc > 15f) return null
            }
        }
        lastGood = loc

        val p = kalman.process(loc.latitude, loc.longitude, acc, loc.time)
        val speed = if (loc.hasSpeed()) loc.speed else 0f
        val bearing = when {
            loc.hasBearing() && speed > 0.8f -> loc.bearing
            else -> lastBearing
        }
        if (loc.hasBearing() && speed > 0.8f) lastBearing = loc.bearing

        return Fix(
            point = p,
            accuracy = acc,
            speed = speed,
            bearing = bearing,
            hasBearing = speed > 0.8f,
            time = if (loc.time > 0) loc.time else System.currentTimeMillis()
        )
    }

    private var lastBearing: Float = 0f

    /** Filtro de Kalman escalar aplicado a latitud/longitud. */
    private class KalmanLatLng(private val processNoise: Float = 2.0f) {
        private var lat = 0.0
        private var lng = 0.0
        private var variance = -1.0
        private var timestamp = 0L

        fun process(newLat: Double, newLng: Double, accuracy: Float, timeMs: Long): GeoPoint {
            val acc = if (accuracy < 1f) 1f else accuracy
            if (variance < 0) {
                lat = newLat; lng = newLng; variance = (acc * acc).toDouble(); timestamp = timeMs
                return GeoPoint(lat, lng)
            }
            val dt = timeMs - timestamp
            if (dt > 0) {
                variance += dt * processNoise * processNoise / 1000.0
                timestamp = timeMs
            }
            val k = variance / (variance + acc * acc)
            lat += k * (newLat - lat)
            lng += k * (newLng - lng)
            variance *= (1 - k)
            return GeoPoint(lat, lng)
        }
    }

    companion object {
        fun isBackgroundAllowed(context: Context): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return true
            return ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_BACKGROUND_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }

        fun bearingChanged(a: Float, b: Float, threshold: Float = 3f): Boolean =
            abs(((a - b + 540f) % 360f) - 180f) > threshold
    }
}
