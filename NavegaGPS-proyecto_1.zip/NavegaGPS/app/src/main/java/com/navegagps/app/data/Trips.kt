package com.navegagps.app.data

import com.navegagps.app.core.GeoPoint

data class TrackPoint(
    val lat: Double,
    val lng: Double,
    val time: Long,
    val speed: Float,
    val accuracy: Float
) {
    fun toGeo() = GeoPoint(lat, lng)
}

data class TripStop(
    val id: Long,
    val lat: Double,
    val lng: Double,
    val startTime: Long,
    val endTime: Long,
    val label: String
) {
    val durationSec: Double get() = (endTime - startTime) / 1000.0
}

data class Trip(
    val id: Long,
    val startedAt: Long,
    val endedAt: Long,
    val originName: String,
    val destName: String,
    val destLat: Double,
    val destLng: Double,
    val distanceMeters: Double,
    val totalSeconds: Double,
    val movingSeconds: Double,
    val stopCount: Int,
    val maxSpeed: Double,
    val avgSpeed: Double
) {
    val avgMovingSpeed: Double get() = if (movingSeconds > 0) distanceMeters / movingSeconds else 0.0
    val stoppedSeconds: Double get() = (totalSeconds - movingSeconds).coerceAtLeast(0.0)
}

data class TripDetail(
    val trip: Trip,
    val points: List<TrackPoint>,
    val stops: List<TripStop>
)

data class TripTotals(
    val trips: Int,
    val distanceMeters: Double,
    val totalSeconds: Double,
    val movingSeconds: Double,
    val stops: Int
)
