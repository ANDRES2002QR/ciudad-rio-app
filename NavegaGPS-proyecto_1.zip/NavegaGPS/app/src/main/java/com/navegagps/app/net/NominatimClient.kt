package com.navegagps.app.net

import android.net.Uri
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.nav.Place
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Búsqueda de direcciones y lugares sobre OpenStreetMap (sin API key). */
object NominatimClient {

    private const val BASE = "https://nominatim.openstreetmap.org"

    suspend fun search(query: String, near: GeoPoint?, limit: Int = 8): List<Place> =
        withContext(Dispatchers.IO) {
            if (query.isBlank()) return@withContext emptyList()
            val sb = StringBuilder(BASE)
            sb.append("/search?format=jsonv2&addressdetails=1&accept-language=es")
            sb.append("&limit=").append(limit)
            sb.append("&q=").append(Uri.encode(query))
            if (near != null) {
                // Prioriza resultados cercanos con un recuadro de ~60 km.
                val d = 0.55
                sb.append(
                    String.format(
                        Locale.US,
                        "&viewbox=%.5f,%.5f,%.5f,%.5f&bounded=0",
                        near.lng - d, near.lat + d, near.lng + d, near.lat - d
                    )
                )
            }
            val arr = JSONArray(Http.getString(sb.toString()))
            val out = ArrayList<Place>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val lat = o.optDouble("lat", Double.NaN)
                val lon = o.optDouble("lon", Double.NaN)
                if (lat.isNaN() || lon.isNaN()) continue
                val display = o.optString("display_name", "")
                val name = o.optString("name", "").ifBlank { display.substringBefore(",") }
                out.add(Place(name.ifBlank { "Lugar" }, display, GeoPoint(lat, lon)))
            }
            out
        }

    suspend fun reverse(point: GeoPoint): Place = withContext(Dispatchers.IO) {
        val url = String.format(
            Locale.US,
            "%s/reverse?format=jsonv2&accept-language=es&lat=%.6f&lon=%.6f&zoom=18",
            BASE, point.lat, point.lng
        )
        try {
            val o = JSONObject(Http.getString(url))
            val display = o.optString("display_name", "")
            val name = o.optString("name", "").ifBlank { display.substringBefore(",") }
            Place(name.ifBlank { "Punto en el mapa" }, display, point)
        } catch (e: Exception) {
            Place(
                "Punto en el mapa",
                String.format(Locale.US, "%.5f, %.5f", point.lat, point.lng),
                point
            )
        }
    }
}
