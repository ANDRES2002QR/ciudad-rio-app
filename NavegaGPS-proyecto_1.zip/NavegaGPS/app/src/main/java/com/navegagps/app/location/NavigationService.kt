package com.navegagps.app.location

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.navegagps.app.MainActivity
import com.navegagps.app.NavegaApp
import com.navegagps.app.R
import com.navegagps.app.core.Format
import com.navegagps.app.nav.Phase
import kotlinx.coroutines.launch

/**
 * Servicio en primer plano: mantiene viva la navegación y la grabación del
 * trayecto aunque la pantalla se apague, y muestra la maniobra en la barra.
 */
class NavigationService : LifecycleService() {

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification("Navegación activa", "Preparando la ruta…"))

        lifecycleScope.launch {
            NavegaApp.instance.controller.state.collect { st ->
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (st.phase != Phase.NAVIGATING && st.recordingTripId == null) {
                    stopSelf()
                    return@collect
                }
                val p = st.progress
                val title = when {
                    p?.nextStep != null -> "${Format.distance(p.distanceToManeuver)} · ${p.nextStep!!.instruction}"
                    st.recordingTripId != null -> "Grabando recorrido"
                    else -> "Navegación activa"
                }
                val text = if (p != null) {
                    "${Format.duration(p.remainingDuration)} · ${Format.distance(p.remainingDistance)} · llegada ${
                        Format.eta(System.currentTimeMillis(), p.remainingDuration)
                    }"
                } else {
                    st.destination?.name ?: "En curso"
                }
                manager.notify(NOTIF_ID, buildNotification(title, text))
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    private fun buildNotification(title: String, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
            .setContentIntent(open)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.nav_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.nav_channel_desc)
                setShowBadge(false)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "navegacion"
        private const val NOTIF_ID = 4501

        fun start(context: Context) {
            val intent = Intent(context, NavigationService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, NavigationService::class.java))
        }
    }
}
