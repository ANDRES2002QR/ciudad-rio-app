package com.navegagps.app.ui

import android.graphics.PointF
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.map.MapRenderer
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style

/**
 * Envoltura de MapLibre para Compose. Mantiene el ciclo de vida del MapView y
 * entrega un [MapRenderer] listo cuando el estilo termina de cargar.
 */
@Composable
fun MapCanvas(
    modifier: Modifier = Modifier,
    styleUrl: String,
    onReady: (MapLibreMap, MapRenderer) -> Unit,
    onTap: (GeoPoint, PointF) -> Unit,
    onLongTap: (GeoPoint) -> Unit,
    onUserGesture: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val mapView = remember { MapView(context) }
    val readyCb = rememberUpdatedState(onReady)
    val tapCb = rememberUpdatedState(onTap)
    val longTapCb = rememberUpdatedState(onLongTap)
    val gestureCb = rememberUpdatedState(onUserGesture)

    DisposableEffect(lifecycleOwner) {
        mapView.onCreate(null)
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            mapView.onDestroy()
        }
    }

    LaunchedEffect(styleUrl) {
        mapView.getMapAsync { map ->
            map.uiSettings.isRotateGesturesEnabled = true
            map.uiSettings.isTiltGesturesEnabled = true
            map.uiSettings.isCompassEnabled = true
            map.uiSettings.isAttributionEnabled = true
            map.uiSettings.isLogoEnabled = false
            map.uiSettings.setCompassMargins(24, 220, 24, 24)

            map.setStyle(Style.Builder().fromUri(styleUrl)) { style ->
                val renderer = MapRenderer(map)
                renderer.attach(style)
                readyCb.value(map, renderer)
            }

            map.addOnMapClickListener { latLng ->
                val screen = map.projection.toScreenLocation(latLng)
                tapCb.value(GeoPoint(latLng.latitude, latLng.longitude), screen)
                true
            }
            map.addOnMapLongClickListener { latLng ->
                longTapCb.value(GeoPoint(latLng.latitude, latLng.longitude))
                true
            }
            map.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE) {
                    gestureCb.value()
                }
            }
        }
    }

    AndroidView(factory = { mapView }, modifier = modifier)
}
