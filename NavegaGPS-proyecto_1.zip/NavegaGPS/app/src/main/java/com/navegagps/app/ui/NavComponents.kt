package com.navegagps.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navegagps.app.core.Format
import com.navegagps.app.nav.Congestion
import com.navegagps.app.nav.Instructions
import com.navegagps.app.nav.LaneInfo
import com.navegagps.app.nav.NavProgress
import com.navegagps.app.nav.NavRoute
import com.navegagps.app.nav.RouteSuggestion

/** Tarjeta superior con la maniobra siguiente, la distancia y la calle. */
@Composable
fun ManeuverCard(progress: NavProgress, modifier: Modifier = Modifier) {
    val step = progress.nextStep ?: progress.currentStep
    val key = step?.let { Instructions.iconKey(it.maneuver.type, it.maneuver.modifier) } ?: "straight"
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = VerdeOscuro),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = ManeuverIcons.of(key),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(54.dp)
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = Format.distance(progress.distanceToManeuver),
                    color = Color.White,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = step?.instruction ?: "Continúa",
                    color = Color(0xFFD1FAE5),
                    fontSize = 16.sp,
                    maxLines = 2
                )
            }
        }
        if (!progress.onRoute) {
            Surface(color = Ambar, modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Fuera de la ruta: recalculando…",
                    modifier = Modifier.padding(8.dp),
                    color = Color(0xFF1F2937),
                    textAlign = TextAlign.Center,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/** Franja de carriles: en verde los que sirven para la maniobra. */
@Composable
fun LaneGuidance(lanes: List<LaneInfo>, modifier: Modifier = Modifier) {
    if (lanes.isEmpty()) return
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xE6111827),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            lanes.forEach { lane ->
                val icon = ManeuverIcons.of(Instructions.laneIcon(lane.indications.firstOrNull() ?: "straight"))
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (lane.valid) Color(0xFF4ADE80) else Color(0xFF64748B),
                    modifier = Modifier
                        .padding(horizontal = 5.dp)
                        .size(if (lane.valid) 34.dp else 28.dp)
                )
            }
        }
    }
}

/** Velocímetro y límite de velocidad de la vía. */
@Composable
fun SpeedPanel(progress: NavProgress, modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Surface(
            shape = CircleShape,
            color = if (progress.overspeed) Rojo else Color(0xCC111827),
            modifier = Modifier.size(64.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(4.dp)
            ) {
                Text(
                    "${progress.speedKmh}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp
                )
                Text("km/h", color = Color(0xFFCBD5E1), fontSize = 10.sp)
            }
        }
        if (progress.speedLimitKmh != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(58.dp)
                    .background(Color.White, CircleShape)
                    .border(5.dp, Rojo, CircleShape)
            ) {
                Text(
                    "${progress.speedLimitKmh}",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }
        }
    }
}

/** Aviso de que hay una ruta mejor. Nunca cambia sola si el modo automático está apagado. */
@Composable
fun SuggestionBanner(
    suggestion: RouteSuggestion,
    autoMode: Boolean,
    onAccept: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Ambar),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AltRoute, null, tint = Color(0xFF1F2937))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "Ruta más rápida disponible",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937)
                    )
                    Text(
                        "${suggestion.route.label} · ahorras ${Format.duration(suggestion.gainSeconds)} · " +
                            Format.distance(suggestion.route.distance),
                        fontSize = 13.sp,
                        color = Color(0xFF374151)
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = VerdeOscuro),
                    modifier = Modifier.weight(1f)
                ) { Text("Cambiar ruta") }
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                    Text("Seguir igual", color = Color(0xFF1F2937))
                }
            }
            if (autoMode) {
                Text(
                    "Modo automático activo: el cambio se aplica solo.",
                    fontSize = 11.sp,
                    color = Color(0xFF4B5563),
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}

/** Fila seleccionable con los datos de una ruta. */
@Composable
fun RouteRow(
    route: NavRoute,
    selected: Boolean,
    trafficLive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val worst = route.traffic.maxByOrNull { it.level.ordinal }?.level ?: Congestion.DESCONOCIDO
    val color = when (worst) {
        Congestion.DETENIDO -> Rojo
        Congestion.LENTO -> Naranja
        Congestion.MODERADO -> Ambar
        else -> Verde
    }
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
        else MaterialTheme.colorScheme.surface,
        border = if (selected)
            androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        tonalElevation = 2.dp
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(color, CircleShape)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(route.label, fontWeight = FontWeight.SemiBold)
                Text(
                    route.summary,
                    fontSize = 12.sp,
                    color = GrisTexto,
                    maxLines = 1
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    Format.duration(route.effectiveDuration()),
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
                Text(Format.distance(route.distance), fontSize = 12.sp, color = GrisTexto)
            }
        }
    }
}

/** Barra inferior durante la navegación. */
@Composable
fun NavBottomBar(
    progress: NavProgress,
    alternativesCount: Int,
    onAlternatives: () -> Unit,
    onOverview: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 12.dp
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        Format.duration(progress.remainingDuration),
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                    Text(
                        "${Format.distance(progress.remainingDistance)} · llegada ${
                            Format.eta(System.currentTimeMillis(), progress.remainingDuration)
                        }",
                        fontSize = 13.sp,
                        color = GrisTexto
                    )
                }
                OutlinedButton(onClick = onAlternatives) {
                    Icon(Icons.Filled.AltRoute, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (alternativesCount > 0) "Rutas ($alternativesCount)" else "Rutas")
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = onOverview) {
                    Icon(Icons.Filled.Map, null, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = onStop,
                    colors = ButtonDefaults.buttonColors(containerColor = Rojo)
                ) {
                    Icon(Icons.Filled.Close, null, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

/** Leyenda del tráfico, con la advertencia de si es estimado o en vivo. */
@Composable
fun TrafficLegend(live: Boolean, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xCC111827)
    ) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Speed, null, tint = Color.White, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                if (live) "Tráfico en vivo" else "Tráfico estimado",
                color = Color.White,
                fontSize = 11.sp
            )
            listOf(Verde, Ambar, Naranja, Rojo).forEach { c ->
                Spacer(Modifier.width(5.dp))
                Box(Modifier.size(9.dp).background(c, CircleShape))
            }
        }
    }
}

/** Flechita que indica el sentido de circulación en la leyenda del mapa. */
@Composable
fun OnewayLegend(modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(12.dp), color = Color(0xCC111827)) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                ManeuverIcons.of("straight"),
                null,
                tint = Azul,
                modifier = Modifier.size(14.dp).rotate(90f)
            )
            Spacer(Modifier.width(6.dp))
            Text("Sentido de las vías", color = Color.White, fontSize = 11.sp)
        }
    }
}
