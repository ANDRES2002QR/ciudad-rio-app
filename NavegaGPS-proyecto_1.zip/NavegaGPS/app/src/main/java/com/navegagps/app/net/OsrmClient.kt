package com.navegagps.app.net

import com.navegagps.app.core.Geo
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.nav.Instructions
import com.navegagps.app.nav.LaneInfo
import com.navegagps.app.nav.Maneuver
import com.navegagps.app.nav.NavRoute
import com.navegagps.app.nav.RouteStep
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Cliente del motor de ruteo OSRM (OpenStreetMap). Devuelve siempre que puede
 * varias rutas alternativas, con pasos, carriles y velocidades por segmento.
 */
class OsrmClient(private val baseUrlProvider: () -> String) {

    class RoutingException(message: String) : Exception(message)

    suspend fun route(
        waypoints: List<GeoPoint>,
        alternatives: Int = 3
    ): List<NavRoute> = withContext(Dispatchers.IO) {
        require(waypoints.size >= 2) { "Se necesitan al menos origen y destino" }

        val coords = waypoints.joinToString(";") {
            String.format(Locale.US, "%.6f,%.6f", it.lng, it.lat)
        }
        val base = baseUrlProvider().trimEnd('/')
        val url = buildString {
            append(base)
            append("/route/v1/driving/")
            append(coords)
            append("?overview=full&geometries=polyline6&steps=true")
            append("&annotations=duration,distance,speed&continue_straight=false")
            append("&alternatives=").append(if (alternatives > 1) alternatives.toString() else "false")
        }

        val body = Http.getString(url)
        val json = JSONObject(body)
        val code = json.optString("code", "Error")
        if (code != "Ok") {
            throw RoutingException(
                when (code) {
                    "NoRoute" -> "No hay una ruta manejable entre esos puntos."
                    "NoSegment" -> "No se encontró una vía cerca de alguno de los puntos."
                    "TooBig" -> "La ruta es demasiado larga para el servidor."
                    else -> "El servidor de rutas respondió: $code"
                }
            )
        }

        val routesJson = json.optJSONArray("routes") ?: JSONArray()
        val out = ArrayList<NavRoute>()
        for (i in 0 until routesJson.length()) {
            val r = routesJson.getJSONObject(i)
            out.add(parseRoute(r, i))
        }
        // La más rápida primero.
        out.sortedBy { it.duration }
    }

    private fun parseRoute(r: JSONObject, index: Int): NavRoute {
        val distance = r.optDouble("distance", 0.0)
        val duration = r.optDouble("duration", 0.0)
        val points = Geo.decodePolyline(r.optString("geometry", ""), 6)

        val steps = ArrayList<RouteStep>()
        val speeds = ArrayList<Double>()
        val names = LinkedHashSet<String>()

        val legs = r.optJSONArray("legs") ?: JSONArray()
        for (l in 0 until legs.length()) {
            val leg = legs.getJSONObject(l)

            leg.optJSONObject("annotation")?.optJSONArray("speed")?.let { sp ->
                for (k in 0 until sp.length()) speeds.add(sp.optDouble(k, 0.0))
            }

            val stepsJson = leg.optJSONArray("steps") ?: JSONArray()
            for (s in 0 until stepsJson.length()) {
                val st = stepsJson.getJSONObject(s)
                val man = st.optJSONObject("maneuver") ?: JSONObject()
                val loc = man.optJSONArray("location")
                val mPoint = if (loc != null && loc.length() >= 2) {
                    GeoPoint(loc.optDouble(1), loc.optDouble(0))
                } else GeoPoint(0.0, 0.0)

                val type = man.optString("type", "continue")
                val modifier = if (man.has("modifier")) man.optString("modifier") else null
                val exit = if (man.has("exit")) man.optInt("exit") else null
                val name = st.optString("name", "")
                val ref = if (st.has("ref")) st.optString("ref") else null

                val lanes = ArrayList<LaneInfo>()
                val inter = st.optJSONArray("intersections")
                if (inter != null && inter.length() > 0) {
                    val lanesJson = inter.getJSONObject(0).optJSONArray("lanes")
                    if (lanesJson != null) {
                        for (k in 0 until lanesJson.length()) {
                            val ln = lanesJson.getJSONObject(k)
                            val indicationsJson = ln.optJSONArray("indications") ?: JSONArray()
                            val indications = ArrayList<String>()
                            for (q in 0 until indicationsJson.length()) {
                                indications.add(indicationsJson.optString(q, "straight"))
                            }
                            lanes.add(
                                LaneInfo(
                                    valid = ln.optBoolean("valid", false),
                                    active = ln.optBoolean("active", ln.optBoolean("valid", false)),
                                    indications = indications
                                )
                            )
                        }
                    }
                }

                val short = Instructions.short(type, modifier, name, ref, exit)
                if (name.isNotBlank() && names.size < 3 && type != "arrive") names.add(name)

                steps.add(
                    RouteStep(
                        name = name,
                        ref = ref,
                        distance = st.optDouble("distance", 0.0),
                        duration = st.optDouble("duration", 0.0),
                        maneuver = Maneuver(
                            type = type,
                            modifier = modifier,
                            location = mPoint,
                            bearingBefore = man.optInt("bearing_before", 0),
                            bearingAfter = man.optInt("bearing_after", 0),
                            exit = exit
                        ),
                        lanes = lanes,
                        geometry = Geo.decodePolyline(st.optString("geometry", ""), 6),
                        instruction = short,
                        voice = short
                    )
                )
            }
        }

        var acc = 0.0
        for (st in steps) {
            st.startDistance = acc
            acc += st.distance
        }

        val speedArray = DoubleArray(maxOf(0, points.size - 1)) { i ->
            speeds.getOrElse(i) { if (duration > 0) distance / duration else 0.0 }
        }

        val summary = if (names.isEmpty()) "Ruta ${index + 1}" else names.joinToString(" · ")
        val labels = listOf("Ruta A", "Ruta B", "Ruta C", "Ruta D", "Ruta E")

        return NavRoute(
            id = "r$index-${distance.toInt()}-${duration.toInt()}",
            label = labels.getOrElse(index) { "Ruta ${index + 1}" },
            distance = distance,
            duration = duration,
            points = points,
            steps = steps,
            segmentSpeeds = speedArray,
            summary = summary
        )
    }
}
