package com.navegagps.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navegagps.app.core.Format
import com.navegagps.app.map.MapRenderer
import com.navegagps.app.nav.Phase
import org.maplibre.android.maps.MapLibreMap

@Composable
fun MapScreen(vm: MainViewModel) {

    val nav by vm.navState.collectAsState()
    val ui by vm.ui.collectAsState()
    val dark = isSystemInDarkTheme()

    var renderer by remember { mutableStateOf<MapRenderer?>(null) }
    var mapRef by remember { mutableStateOf<MapLibreMap?>(null) }
    var showAlternatives by remember { mutableStateOf(false) }
    var overview by remember { mutableStateOf(false) }

    val styleUrl = if (dark) MapRenderer.STYLE_NIGHT else MapRenderer.STYLE_DAY

    Box(Modifier.fillMaxSize()) {

        MapCanvas(
            modifier = Modifier.fillMaxSize(),
            styleUrl = styleUrl,
            onReady = { m, r ->
                mapRef = m
                r.onewayVisible = vm.prefs.showOnewayArrows
                r.trafficVisible = vm.prefs.showTraffic
                renderer = r
            },
            onTap = { _, screen ->
                val id = renderer?.alternativeAt(screen)
                if (id != null) {
                    vm.controller.selectRoute(id)
                    vm.showMessage("Ruta cambiada")
                }
            },
            onLongTap = { point -> vm.chooseFromMap(point) },
            onUserGesture = { vm.setFollow(false) }
        )

        // ---- sincronización del mapa con el estado ----

        LaunchedEffect(renderer, nav.routes, nav.activeRouteId) {
            val r = renderer ?: return@LaunchedEffect
            r.setRoute(nav.activeRoute, vm.prefs.showTraffic)
            r.setAlternatives(nav.alternatives) { route ->
                "${route.label} · ${Format.duration(route.effectiveDuration())}"
            }
        }

        // Aplica al mapa los cambios hechos en Ajustes al volver a esta pantalla.
        LaunchedEffect(renderer, ui.screen) {
            val r = renderer ?: return@LaunchedEffect
            r.onewayVisible = vm.prefs.showOnewayArrows
            r.trafficVisible = vm.prefs.showTraffic
            r.setRoute(nav.activeRoute, vm.prefs.showTraffic)
        }

        LaunchedEffect(renderer, nav.destination) {
            renderer?.setMarkers(nav.destination?.point)
        }

        LaunchedEffect(renderer, nav.fix, ui.followCamera, overview) {
            val r = renderer ?: return@LaunchedEffect
            val fix = nav.fix ?: return@LaunchedEffect
            val shown = nav.progress?.snapped ?: fix.point
            r.setPuck(shown, fix.bearing)
            if (ui.followCamera && !overview) {
                if (nav.phase == Phase.NAVIGATING) {
                    r.follow(shown, fix.bearing, vm.prefs.northUp)
                } else {
                    r.center(shown, 16.0)
                }
            }
        }

        LaunchedEffect(renderer, nav.phase, nav.activeRouteId, overview) {
            val r = renderer ?: return@LaunchedEffect
            val route = nav.activeRoute
            if ((nav.phase == Phase.PREVIEW || overview) && route != null) {
                r.fit(route.points)
            }
        }

        // ---- capa superior ----

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            if (nav.phase == Phase.NAVIGATING && nav.progress != null) {
                ManeuverCard(nav.progress!!)
                Spacer(Modifier.height(8.dp))
                LaneGuidance(nav.progress!!.lanes)
            } else {
                TopSearchBar(
                    text = nav.destination?.name ?: "¿A dónde vamos?",
                    onSearch = { vm.go(Screen.BUSCAR) },
                    onHistory = { vm.go(Screen.HISTORIAL) },
                    onSettings = { vm.go(Screen.AJUSTES) }
                )
            }
            nav.suggestion?.let { s ->
                Spacer(Modifier.height(8.dp))
                SuggestionBanner(
                    suggestion = s,
                    autoMode = vm.prefs.autoSwitchRoutes,
                    onAccept = { vm.controller.acceptSuggestion() },
                    onDismiss = { vm.controller.dismissSuggestion() }
                )
            }
        }

        // ---- columna derecha ----

        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (nav.phase == Phase.NAVIGATING && nav.progress != null) {
                SpeedPanel(nav.progress!!)
            }
            FloatingActionButton(
                onClick = {
                    vm.setFollow(true)
                    overview = false
                    nav.fix?.let { f -> renderer?.center(f.point, 16.5) }
                },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Icon(
                    Icons.Filled.MyLocation,
                    contentDescription = "Centrar en mi ubicación",
                    tint = if (ui.followCamera) MaterialTheme.colorScheme.primary else GrisTexto
                )
            }
            if (nav.phase == Phase.NAVIGATING) {
                FloatingActionButton(
                    onClick = { vm.controller.refreshAlternativesNow() },
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Buscar otras rutas")
                }
            }
        }

        // ---- leyendas ----
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 12.dp, bottom = 190.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (vm.prefs.showTraffic) TrafficLegend(nav.trafficLive)
            if (vm.prefs.showOnewayArrows) OnewayLegend()
        }

        // ---- capa inferior ----

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            if (nav.loading) {
                Row(
                    Modifier.fillMaxWidth().padding(10.dp),
                    horizontalArrangement = Arrangement.Center
                ) { CircularProgressIndicator() }
            }

            when {
                showAlternatives && nav.phase == Phase.NAVIGATING ->
                    AlternativesPanel(
                        vm = vm,
                        onClose = { showAlternatives = false }
                    )

                nav.phase == Phase.PREVIEW -> RoutePreviewPanel(vm)

                nav.phase == Phase.NAVIGATING && nav.progress != null ->
                    NavBottomBar(
                        progress = nav.progress!!,
                        alternativesCount = nav.alternatives.size,
                        onAlternatives = { showAlternatives = true },
                        onOverview = { overview = !overview; vm.setFollow(!overview) },
                        onStop = { vm.controller.stopNavigation(false) }
                    )

                else -> IdlePanel(vm)
            }
        }
    }
}

@Composable
private fun TopSearchBar(
    text: String,
    onSearch: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = onSearch,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(text, maxLines = 1)
            }
            IconButton(onClick = onHistory) {
                Icon(Icons.Filled.History, contentDescription = "Historial", tint = GrisTexto)
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Ajustes", tint = GrisTexto)
            }
        }
    }
}

/** Panel cuando no hay ruta: accesos rápidos y grabación libre. */
@Composable
private fun IdlePanel(vm: MainViewModel) {
    val ui by vm.ui.collectAsState()
    val nav by vm.navState.collectAsState()
    Surface(
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 10.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Destinos rápidos", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            val quick = (ui.favorites + ui.recents).distinctBy { it.point.lat to it.point.lng }.take(4)
            if (quick.isEmpty()) {
                Text(
                    "Busca una dirección, o mantén pulsado un punto del mapa para fijar el destino.",
                    fontSize = 13.sp,
                    color = GrisTexto
                )
            } else {
                quick.forEach { place ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(place.name, maxLines = 1, fontWeight = FontWeight.Medium)
                            Text(place.address, maxLines = 1, fontSize = 11.sp, color = GrisTexto)
                        }
                        Button(onClick = { vm.chooseDestination(place) }) { Text("Ir") }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { vm.go(Screen.BUSCAR) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Buscar destino")
                }
                if (nav.recordingTripId == null) {
                    OutlinedButton(onClick = { vm.controller.startFreeRecording() }) {
                        Icon(Icons.Filled.FiberManualRecord, null, tint = Rojo, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Grabar")
                    }
                } else {
                    Button(
                        onClick = { vm.controller.stopFreeRecording(); vm.refreshHistory() },
                        colors = ButtonDefaults.buttonColors(containerColor = Rojo)
                    ) {
                        Icon(Icons.Filled.Stop, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Detener")
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = { vm.go(Screen.HISTORIAL) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.History, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Historial")
                }
                OutlinedButton(onClick = { vm.go(Screen.AJUSTES) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Settings, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Ajustes")
                }
            }
        }
    }
}

/** Panel previo al viaje: elige entre las rutas y arranca. */
@Composable
private fun RoutePreviewPanel(vm: MainViewModel) {
    val nav by vm.navState.collectAsState()
    Surface(
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 12.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                nav.destination?.name ?: "Destino",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                maxLines = 1
            )
            Text(
                nav.destination?.address ?: "",
                fontSize = 12.sp,
                color = GrisTexto,
                maxLines = 2
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Elige la ruta (puedes cambiarla también en movimiento)",
                fontSize = 12.sp,
                color = GrisTexto
            )
            Spacer(Modifier.height(8.dp))
            Column(
                modifier = Modifier
                    .heightIn(max = 230.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                nav.routes.forEach { route ->
                    RouteRow(
                        route = route,
                        selected = route.id == nav.activeRouteId,
                        trafficLive = nav.trafficLive,
                        onClick = { vm.controller.selectRoute(route.id) }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { vm.controller.startNavigation(); vm.setFollow(true) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Verde)
                ) {
                    Icon(Icons.Filled.Navigation, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("INICIAR RUTA", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = { vm.controller.cancelPreview() }) { Text("Cancelar") }
            }
            nav.destination?.let { dest ->
                OutlinedButton(
                    onClick = { vm.saveFavorite(dest) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text("Guardar en favoritos") }
            }
        }
    }
}

/** Lista de rutas disponible DURANTE el viaje: el conductor elige cuando quiera. */
@Composable
private fun AlternativesPanel(vm: MainViewModel, onClose: () -> Unit) {
    val nav by vm.navState.collectAsState()
    Surface(
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 14.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Rutas disponibles ahora", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { vm.controller.refreshAlternativesNow() }) {
                    Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Actualizar")
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Toca una para cambiar. Si no tocas nada, sigues por la ruta actual.",
                fontSize = 12.sp,
                color = GrisTexto
            )
            Spacer(Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .heightIn(max = 260.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                nav.routes.forEach { route ->
                    RouteRow(
                        route = route,
                        selected = route.id == nav.activeRouteId,
                        trafficLive = nav.trafficLive,
                        onClick = {
                            vm.controller.selectRoute(route.id)
                            onClose()
                        }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Cerrar") }
        }
    }
}
