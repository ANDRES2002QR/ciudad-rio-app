package com.navegagps.app.net

import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

object Http {

    /** Nominatim y Overpass exigen un User-Agent identificable. */
    const val USER_AGENT = "NavegaGPS/1.0 (app de navegacion personal)"

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(40, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun getString(url: String): String = suspendCancellableCoroutine { cont ->
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/json")
            .build()
        val call = client.newCall(req)
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : okhttp3.Callback {
            override fun onFailure(c: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(c: Call, response: Response) {
                response.use { r ->
                    if (!r.isSuccessful) {
                        if (cont.isActive) cont.resumeWithException(IOException("HTTP ${r.code}"))
                        return
                    }
                    val body = r.body?.string() ?: ""
                    if (cont.isActive) cont.resume(body)
                }
            }
        })
    }
}
