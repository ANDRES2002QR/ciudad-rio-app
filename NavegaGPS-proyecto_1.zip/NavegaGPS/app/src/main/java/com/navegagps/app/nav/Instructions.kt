package com.navegagps.app.nav

import com.navegagps.app.core.Format

/**
 * Traduce las maniobras de OSRM a instrucciones en español, en dos versiones:
 * una corta para la tarjeta y otra hablada para el TTS.
 */
object Instructions {

    private fun dir(modifier: String?): String = when (modifier) {
        "left" -> "a la izquierda"
        "right" -> "a la derecha"
        "slight left" -> "levemente a la izquierda"
        "slight right" -> "levemente a la derecha"
        "sharp left" -> "cerrado a la izquierda"
        "sharp right" -> "cerrado a la derecha"
        "straight" -> "recto"
        "uturn" -> "en U"
        else -> ""
    }

    private fun on(name: String, ref: String?): String {
        val n = name.trim()
        val r = ref?.trim().orEmpty()
        return when {
            n.isNotEmpty() && r.isNotEmpty() && n != r -> " hacia $n ($r)"
            n.isNotEmpty() -> " hacia $n"
            r.isNotEmpty() -> " hacia $r"
            else -> ""
        }
    }

    private fun ordinal(exit: Int?): String = when (exit) {
        1 -> "la primera salida"
        2 -> "la segunda salida"
        3 -> "la tercera salida"
        4 -> "la cuarta salida"
        5 -> "la quinta salida"
        6 -> "la sexta salida"
        else -> "la salida indicada"
    }

    /** Texto corto que se muestra en la tarjeta de maniobra. */
    fun short(type: String, modifier: String?, name: String, ref: String?, exit: Int?): String {
        val d = dir(modifier)
        val destino = on(name, ref)
        return when (type) {
            "depart" -> "Inicia el recorrido$destino"
            "arrive" -> when (modifier) {
                "left" -> "Llegaste, destino a la izquierda"
                "right" -> "Llegaste, destino a la derecha"
                else -> "Llegaste a tu destino"
            }
            "turn" -> if (modifier == "uturn") "Haz un retorno$destino" else "Gira $d$destino"
            "new name" -> "Continúa$destino"
            "continue" -> if (modifier == "uturn") "Haz un retorno$destino" else "Continúa $d$destino"
            "merge" -> "Incorpórate $d$destino"
            "on ramp" -> "Toma la rampa $d$destino"
            "off ramp" -> "Toma la salida $d$destino"
            "fork" -> "En la bifurcación mantente $d$destino"
            "end of road" -> "Al final de la vía gira $d$destino"
            "roundabout", "rotary" -> "En la glorieta toma ${ordinal(exit)}$destino"
            "roundabout turn" -> "En la glorieta gira $d$destino"
            "exit roundabout", "exit rotary" -> "Sal de la glorieta$destino"
            "notification" -> "Continúa$destino"
            else -> if (d.isNotEmpty()) "Gira $d$destino" else "Continúa$destino"
        }.trim()
    }

    /** Frase hablada, anteponiendo la distancia cuando corresponde. */
    fun spoken(base: String, meters: Double?): String {
        if (meters == null || meters < 30) return base
        val dist = when {
            meters < 120 -> "En ${(meters / 10).toInt() * 10} metros"
            meters < 1000 -> "En ${(meters / 50).toInt() * 50} metros"
            else -> "En ${Format.distance(meters)}"
        }
        return "$dist, ${base.replaceFirstChar { it.lowercase() }}"
    }

    /** Icono lógico para la tarjeta (lo resuelve la UI). */
    fun iconKey(type: String, modifier: String?): String = when (type) {
        "arrive" -> "flag"
        "depart" -> "straight"
        "roundabout", "rotary", "roundabout turn" ->
            if (modifier != null && modifier.contains("left")) "roundabout_left" else "roundabout_right"
        "merge" -> "merge"
        "on ramp" -> if (modifier != null && modifier.contains("left")) "ramp_left" else "ramp_right"
        "off ramp" -> if (modifier != null && modifier.contains("left")) "ramp_left" else "ramp_right"
        "fork" -> if (modifier != null && modifier.contains("left")) "fork_left" else "fork_right"
        else -> when (modifier) {
            "left" -> "turn_left"
            "right" -> "turn_right"
            "slight left" -> "slight_left"
            "slight right" -> "slight_right"
            "sharp left" -> "sharp_left"
            "sharp right" -> "sharp_right"
            "uturn" -> "uturn"
            else -> "straight"
        }
    }

    /** Traduce las indicaciones de carril de OSRM a iconos/etiquetas. */
    fun laneIcon(indication: String): String = when (indication) {
        "left" -> "turn_left"
        "right" -> "turn_right"
        "slight left" -> "slight_left"
        "slight right" -> "slight_right"
        "sharp left" -> "sharp_left"
        "sharp right" -> "sharp_right"
        "uturn" -> "uturn"
        "straight", "none" -> "straight"
        "merge to left" -> "slight_left"
        "merge to right" -> "slight_right"
        else -> "straight"
    }
}
