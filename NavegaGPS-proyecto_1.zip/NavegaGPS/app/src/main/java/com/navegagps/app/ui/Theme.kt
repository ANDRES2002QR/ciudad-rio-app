package com.navegagps.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Verde = Color(0xFF16A34A)
val VerdeOscuro = Color(0xFF0B3D2E)
val Ambar = Color(0xFFF59E0B)
val Rojo = Color(0xFFDC2626)
val Naranja = Color(0xFFF97316)
val Azul = Color(0xFF1F6FEB)
val GrisTexto = Color(0xFF475569)

private val LightColors = lightColorScheme(
    primary = Verde,
    onPrimary = Color.White,
    secondary = Azul,
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    error = Rojo
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF07281C),
    secondary = Color(0xFF60A5FA),
    background = Color(0xFF0B1220),
    surface = Color(0xFF111827),
    onSurface = Color(0xFFE2E8F0),
    error = Color(0xFFF87171)
)

@Composable
fun NavegaTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(),
        content = content
    )
}
