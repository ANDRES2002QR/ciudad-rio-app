package com.navegagps.app.core

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Punto geográfico simple (evita chocar con LatLng de MapLibre). */
data class GeoPoint(val lat: Double, val lng: Double) {
    fun isValid(): Boolean = lat >= -90.0 && lat <= 90.0 && lng >= -180.0 && lng <= 180.0
}

data class Projection(
    val point: GeoPoint,
    /** índice del primer vértice del segmento donde cae la proyección */
    val index: Int,
    /** 0..1 dentro del segmento */
    val t: Double,
    /** distancia perpendicular en metros */
    val offsetMeters: Double
)

object Geo {

    private const val EARTH_RADIUS = 6371008.8
    private const val DEG = Math.PI / 180.0

    fun distance(a: GeoPoint, b: GeoPoint): Double {
        val dLat = (b.lat - a.lat) * DEG
        val dLng = (b.lng - a.lng) * DEG
        val la1 = a.lat * DEG
        val la2 = b.lat * DEG
        val h = sin(dLat / 2) * sin(dLat / 2) + cos(la1) * cos(la2) * sin(dLng / 2) * sin(dLng / 2)
        return 2 * EARTH_RADIUS * atan2(sqrt(h), sqrt(1 - h))
    }

    /** Rumbo en grados 0..360 desde a hacia b. */
    fun bearing(a: GeoPoint, b: GeoPoint): Double {
        val la1 = a.lat * DEG
        val la2 = b.lat * DEG
        val dLng = (b.lng - a.lng) * DEG
        val y = sin(dLng) * cos(la2)
        val x = cos(la1) * sin(la2) - sin(la1) * cos(la2) * cos(dLng)
        val deg = Math.toDegrees(atan2(y, x))
        return (deg + 360.0) % 360.0
    }

    /** Diferencia angular con signo entre dos rumbos, en el rango -180..180. */
    fun angleDelta(from: Double, to: Double): Double {
        var d = (to - from + 540.0) % 360.0 - 180.0
        if (d == -180.0) d = 180.0
        return d
    }

    /** Decodifica una polilínea codificada de Google/OSRM. precision 5 o 6. */
    fun decodePolyline(encoded: String, precision: Int = 6): List<GeoPoint> {
        val factor = Math.pow(10.0, precision.toDouble())
        val out = ArrayList<GeoPoint>(encoded.length / 4 + 1)
        var index = 0
        var lat = 0
        var lng = 0
        while (index < encoded.length) {
            var result = 1
            var shift = 0
            var b: Int
            do {
                b = encoded[index++].code - 63 - 1
                result += b shl shift
                shift += 5
            } while (b >= 0x1f && index < encoded.length)
            lat += if (result and 1 != 0) (result shr 1).inv() else (result shr 1)

            result = 1
            shift = 0
            do {
                b = encoded[index++].code - 63 - 1
                result += b shl shift
                shift += 5
            } while (b >= 0x1f && index < encoded.length)
            lng += if (result and 1 != 0) (result shr 1).inv() else (result shr 1)

            out.add(GeoPoint(lat / factor, lng / factor))
        }
        return out
    }

    /** Distancias acumuladas (metros) a lo largo de la polilínea. */
    fun cumulative(points: List<GeoPoint>): DoubleArray {
        val acc = DoubleArray(points.size)
        for (i in 1 until points.size) acc[i] = acc[i - 1] + distance(points[i - 1], points[i])
        return acc
    }

    fun length(points: List<GeoPoint>): Double {
        if (points.size < 2) return 0.0
        var d = 0.0
        for (i in 1 until points.size) d += distance(points[i - 1], points[i])
        return d
    }

    /**
     * Proyecta [p] sobre la polilínea. Si [fromIndex] > 0 se busca solo en una ventana
     * hacia adelante, lo que hace el map-matching estable y barato durante la navegación.
     */
    fun project(points: List<GeoPoint>, p: GeoPoint, fromIndex: Int = 0, window: Int = -1): Projection {
        if (points.isEmpty()) return Projection(p, 0, 0.0, 0.0)
        if (points.size == 1) return Projection(points[0], 0, 0.0, distance(points[0], p))

        val start = max(0, min(fromIndex, points.size - 2))
        val end = if (window <= 0) points.size - 2 else min(points.size - 2, start + window)

        val mLat = 111320.0
        val mLng = 111320.0 * cos(p.lat * DEG)

        var bestIdx = start
        var bestT = 0.0
        var bestDist2 = Double.MAX_VALUE
        var bestX = 0.0
        var bestY = 0.0

        val px = p.lng * mLng
        val py = p.lat * mLat

        for (i in start..end) {
            val ax = points[i].lng * mLng
            val ay = points[i].lat * mLat
            val bx = points[i + 1].lng * mLng
            val by = points[i + 1].lat * mLat
            val dx = bx - ax
            val dy = by - ay
            val len2 = dx * dx + dy * dy
            var t = if (len2 <= 0.0) 0.0 else ((px - ax) * dx + (py - ay) * dy) / len2
            if (t < 0.0) t = 0.0
            if (t > 1.0) t = 1.0
            val qx = ax + t * dx
            val qy = ay + t * dy
            val d2 = (px - qx) * (px - qx) + (py - qy) * (py - qy)
            if (d2 < bestDist2) {
                bestDist2 = d2
                bestIdx = i
                bestT = t
                bestX = qx
                bestY = qy
            }
        }
        val snapped = GeoPoint(bestY / mLat, bestX / mLng)
        return Projection(snapped, bestIdx, bestT, sqrt(bestDist2))
    }

    /** Distancia recorrida sobre la polilínea hasta la proyección. */
    fun distanceAlong(points: List<GeoPoint>, acc: DoubleArray, pr: Projection): Double {
        if (points.size < 2) return 0.0
        val i = min(pr.index, points.size - 2)
        val segLen = acc[i + 1] - acc[i]
        return acc[i] + segLen * pr.t
    }

    /** minLat, minLng, maxLat, maxLng */
    fun bbox(points: List<GeoPoint>): DoubleArray {
        var minLat = 90.0; var minLng = 180.0; var maxLat = -90.0; var maxLng = -180.0
        for (p in points) {
            if (p.lat < minLat) minLat = p.lat
            if (p.lat > maxLat) maxLat = p.lat
            if (p.lng < minLng) minLng = p.lng
            if (p.lng > maxLng) maxLng = p.lng
        }
        return doubleArrayOf(minLat, minLng, maxLat, maxLng)
    }

    /** Punto a [meters] metros del inicio de la polilínea. */
    fun interpolate(points: List<GeoPoint>, meters: Double): GeoPoint {
        if (points.isEmpty()) return GeoPoint(0.0, 0.0)
        if (points.size == 1 || meters <= 0) return points.first()
        var rest = meters
        for (i in 1 until points.size) {
            val d = distance(points[i - 1], points[i])
            if (rest <= d) {
                val t = if (d == 0.0) 0.0 else rest / d
                return GeoPoint(
                    points[i - 1].lat + (points[i].lat - points[i - 1].lat) * t,
                    points[i - 1].lng + (points[i].lng - points[i - 1].lng) * t
                )
            }
            rest -= d
        }
        return points.last()
    }

    /** Simplificación Douglas-Peucker (para dibujar historiales largos). */
    fun simplify(points: List<GeoPoint>, toleranceMeters: Double): List<GeoPoint> {
        if (points.size < 3) return points
        val keep = BooleanArray(points.size)
        keep[0] = true
        keep[points.size - 1] = true
        val stack = ArrayDeque<Pair<Int, Int>>()
        stack.addLast(0 to points.size - 1)
        while (stack.isNotEmpty()) {
            val (s, e) = stack.removeLast()
            var maxD = 0.0
            var idx = -1
            for (i in s + 1 until e) {
                val pr = project(listOf(points[s], points[e]), points[i])
                if (pr.offsetMeters > maxD) { maxD = pr.offsetMeters; idx = i }
            }
            if (idx > 0 && maxD > toleranceMeters) {
                keep[idx] = true
                stack.addLast(s to idx)
                stack.addLast(idx to e)
            }
        }
        return points.filterIndexed { i, _ -> keep[i] }
    }

    fun clamp(v: Double, lo: Double, hi: Double): Double = max(lo, min(hi, v))

    fun approxEquals(a: GeoPoint, b: GeoPoint, meters: Double = 5.0): Boolean =
        abs(a.lat - b.lat) < 0.001 && abs(a.lng - b.lng) < 0.001 && distance(a, b) < meters
}
