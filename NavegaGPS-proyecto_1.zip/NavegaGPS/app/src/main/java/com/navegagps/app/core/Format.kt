package com.navegagps.app.core

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/** Formatos en español, pensados para leerse de un vistazo mientras se conduce. */
object Format {

    private val esCO = Locale("es", "CO")

    fun distance(meters: Double): String = when {
        meters.isNaN() -> "--"
        meters < 10 -> "ahora"
        meters < 1000 -> "${(meters / 10).roundToInt() * 10} m"
        meters < 10000 -> String.format(esCO, "%.1f km", meters / 1000.0)
        else -> "${(meters / 1000.0).roundToInt()} km"
    }

    fun distanceLong(meters: Double): String =
        if (meters < 1000) "${meters.roundToInt()} m"
        else String.format(esCO, "%.2f km", meters / 1000.0)

    fun duration(seconds: Double): String {
        if (seconds.isNaN() || seconds < 0) return "--"
        val total = seconds.roundToLong()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return when {
            h > 0 -> "${h} h ${m} min"
            m > 0 -> "${m} min"
            else -> "${s} s"
        }
    }

    fun durationPrecise(seconds: Double): String {
        val total = seconds.roundToLong()
        return String.format(esCO, "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }

    fun speedKmh(metersPerSecond: Double): String =
        "${(metersPerSecond * 3.6).roundToInt()} km/h"

    fun eta(nowMillis: Long, remainingSeconds: Double): String {
        val fmt = SimpleDateFormat("h:mm a", esCO)
        return fmt.format(Date(nowMillis + (remainingSeconds * 1000).toLong()))
    }

    fun dateTime(millis: Long): String =
        SimpleDateFormat("d MMM yyyy, h:mm a", esCO).format(Date(millis))

    fun dayHeader(millis: Long): String =
        SimpleDateFormat("EEEE d 'de' MMMM", esCO).format(Date(millis)).replaceFirstChar { it.uppercase() }
}
