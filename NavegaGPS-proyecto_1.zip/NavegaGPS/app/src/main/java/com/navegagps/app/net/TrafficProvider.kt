package com.navegagps.app.net

import com.navegagps.app.core.Geo
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.nav.Congestion
import com.navegagps.app.nav.NavRoute
import com.navegagps.app.nav.TrafficSegment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Tráfico de la ruta.
 *
 * - Sin clave: ESTIMADO. Combina la velocidad que el motor de ruteo asigna a cada
 *   tramo, el límite de velocidad real de OSM y un factor de hora pico. Es una
 *   estimación honesta, no un dato en vivo, y así se rotula en la interfaz.
 * - Con clave de TomTom (gratuita): tráfico REAL, muestreando puntos de la ruta.
 */
object TrafficProvider {

    data class Result(val segments: List<TrafficSegment>, val live: Boolean)

    suspend fun forRoute(
        route: NavRoute,
        roads: OverpassClient.RoadIndex?,
        tomtomKey: String
    ): Result {
        if (tomtomKey.isNotBlank()) {
            val live = runCatching { fromTomTom(route, tomtomKey) }.getOrNull()
            if (live != null && live.isNotEmpty()) return Result(live, true)
        }
        return Result(estimate(route, roads), false)
    }

    /** Estimación local, sin red adicional. */
    fun estimate(route: NavRoute, roads: OverpassClient.RoadIndex?): List<TrafficSegment> {
        val pts = route.points
        if (pts.size < 2) return emptyList()

        val peak = peakFactor()
        val out = ArrayList<TrafficSegment>()
        var runStart = 0
        var runLevel: Congestion? = null

        for (i in 0 until pts.size - 1) {
            val routed = route.segmentSpeeds.getOrElse(i) { 0.0 } // m/s
            val limitKmh = roads?.nearest(pts[i], 30.0)?.maxSpeedKmh
            val freeFlow = when {
                limitKmh != null && limitKmh > 0 -> limitKmh / 3.6
                else -> max(routed, 8.3)
            }
            val effective = routed * (1.0 / peakOnRoad(peak, freeFlow))
            val ratio = if (freeFlow > 0) effective / freeFlow else 1.0

            val level = when {
                routed <= 0.0 -> Congestion.DESCONOCIDO
                ratio >= 0.8 -> Congestion.FLUIDO
                ratio >= 0.55 -> Congestion.MODERADO
                ratio >= 0.3 -> Congestion.LENTO
                else -> Congestion.DETENIDO
            }

            if (runLevel == null) {
                runLevel = level
                runStart = i
            } else if (level != runLevel) {
                out.add(TrafficSegment(runStart, i, runLevel))
                runLevel = level
                runStart = i
            }
        }
        runLevel?.let { out.add(TrafficSegment(runStart, pts.size - 1, it)) }
        return out.filter { it.toIndex > it.fromIndex }
    }

    /** 1.0 = sin hora pico; >1 = circulación más lenta de lo que dice el ruteo. */
    private fun peakFactor(): Double {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60.0
        val dow = c.get(Calendar.DAY_OF_WEEK)
        val weekend = dow == Calendar.SATURDAY || dow == Calendar.SUNDAY
        if (weekend) return if (h in 11.0..14.0 || h in 17.0..20.0) 1.15 else 1.0
        return when {
            h >= 6.0 && h < 9.0 -> 1.45
            h >= 9.0 && h < 11.0 -> 1.15
            h >= 11.5 && h < 14.0 -> 1.2
            h >= 16.5 && h < 20.0 -> 1.5
            h >= 20.0 && h < 22.0 -> 1.15
            else -> 1.0
        }
    }

    /** La hora pico pega más fuerte en vías urbanas lentas que en autopistas. */
    private fun peakOnRoad(peak: Double, freeFlowMs: Double): Double {
        val urban = freeFlowMs < 22.0 // < ~80 km/h
        return if (urban) peak else 1.0 + (peak - 1.0) * 0.5
    }

    /** Tráfico real de TomTom muestreando la ruta. */
    private suspend fun fromTomTom(route: NavRoute, key: String): List<TrafficSegment> =
        withContext(Dispatchers.IO) {
            val pts = route.points
            if (pts.size < 2) return@withContext emptyList()
            val samples = min(14, max(4, (route.distance / 1500.0).toInt()))
            val acc = Geo.cumulative(pts)
            val total = acc.last()
            val out = ArrayList<TrafficSegment>()

            for (s in 0 until samples) {
                val target = total * (s + 0.5) / samples
                var idx = 0
                while (idx < acc.size - 1 && acc[idx + 1] < target) idx++
                val p: GeoPoint = pts[idx]
                val url = String.format(
                    Locale.US,
                    "https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json?point=%.6f,%.6f&unit=KMPH&key=%s",
                    p.lat, p.lng, key
                )
                val body = runCatching { Http.getString(url) }.getOrNull() ?: continue
                val seg = JSONObject(body).optJSONObject("flowSegmentData") ?: continue
                val current = seg.optDouble("currentSpeed", -1.0)
                val free = seg.optDouble("freeFlowSpeed", -1.0)
                if (current <= 0 || free <= 0) continue
                val ratio = current / free
                val level = when {
                    ratio >= 0.8 -> Congestion.FLUIDO
                    ratio >= 0.55 -> Congestion.MODERADO
                    ratio >= 0.3 -> Congestion.LENTO
                    else -> Congestion.DETENIDO
                }
                val from = idx
                val to = min(pts.size - 1, idx + max(1, (pts.size / samples)))
                out.add(TrafficSegment(from, to, level))
            }
            out.sortedBy { it.fromIndex }
        }
}
