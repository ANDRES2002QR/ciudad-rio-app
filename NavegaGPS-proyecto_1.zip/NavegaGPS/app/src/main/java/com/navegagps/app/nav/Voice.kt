package com.navegagps.app.nav

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Instrucciones habladas en español. */
class Voice(context: Context) {

    private var tts: TextToSpeech? = null
    private var ready = false
    var enabled: Boolean = true

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                val candidates = listOf(
                    Locale("es", "CO"), Locale("es", "MX"), Locale("es", "US"),
                    Locale("es", "ES"), Locale("es")
                )
                for (loc in candidates) {
                    val r = engine.setLanguage(loc)
                    if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) break
                }
                engine.setSpeechRate(1.02f)
                engine.setPitch(1.0f)
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {}
                    @Deprecated("Requerido por la clase base")
                    override fun onError(utteranceId: String?) {}
                })
                ready = true
            }
        }
    }

    fun speak(text: String, urgent: Boolean = false) {
        if (!enabled || !ready || text.isBlank()) return
        val mode = if (urgent) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        tts?.speak(text, mode, null, "navegagps-${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null
        ready = false
    }
}
