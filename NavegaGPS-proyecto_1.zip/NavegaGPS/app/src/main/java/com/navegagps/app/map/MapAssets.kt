package com.navegagps.app.map

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path

/** Iconos dibujados por código: no dependen de recursos ni de densidad. */
object MapAssets {

    const val ONEWAY_ARROW = "navega-oneway-arrow"
    const val PUCK = "navega-puck"
    const val DESTINATION = "navega-destination"
    const val WAYPOINT = "navega-waypoint"

    /** Flecha pequeña que se repite sobre las calles de sentido único. */
    fun onewayArrow(): Bitmap {
        val w = 36
        val h = 36
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1F6FEB")
            style = Paint.Style.FILL
        }
        val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        // Flecha apuntando hacia la derecha (el eje X sigue la dirección de la vía).
        val p = Path().apply {
            moveTo(w * 0.18f, h * 0.30f)
            lineTo(w * 0.78f, h * 0.50f)
            lineTo(w * 0.18f, h * 0.70f)
            lineTo(w * 0.34f, h * 0.50f)
            close()
        }
        c.drawPath(p, halo)
        c.drawPath(p, body)
        return bmp
    }

    /** Indicador de posición del vehículo (flecha dentro de un círculo). */
    fun puck(): Bitmap {
        val s = 96
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#33000000") }
        val circle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B8E4B") }
        c.drawCircle(s / 2f, s / 2f + 2f, s * 0.40f, shadow)
        c.drawCircle(s / 2f, s / 2f, s * 0.38f, circle)
        // Flecha apuntando hacia arriba (0 grados = norte).
        val p = Path().apply {
            moveTo(s * 0.50f, s * 0.18f)
            lineTo(s * 0.75f, s * 0.78f)
            lineTo(s * 0.50f, s * 0.64f)
            lineTo(s * 0.25f, s * 0.78f)
            close()
        }
        c.drawPath(p, arrow)
        return bmp
    }

    fun destinationPin(): Bitmap = pin(Color.parseColor("#D92D20"))

    fun waypointPin(): Bitmap = pin(Color.parseColor("#1F6FEB"))

    private fun pin(color: Int): Bitmap {
        val w = 72
        val h = 96
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 5f
        }
        val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE }
        val path = Path().apply {
            addCircle(w / 2f, h * 0.36f, w * 0.40f, Path.Direction.CW)
            moveTo(w * 0.22f, h * 0.60f)
            lineTo(w / 2f, h * 0.96f)
            lineTo(w * 0.78f, h * 0.60f)
            close()
        }
        c.drawPath(path, body)
        c.drawPath(path, stroke)
        c.drawCircle(w / 2f, h * 0.36f, w * 0.15f, hole)
        return bmp
    }
}
