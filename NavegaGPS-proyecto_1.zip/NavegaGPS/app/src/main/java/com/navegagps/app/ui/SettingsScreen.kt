package com.navegagps.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val prefs = vm.prefs

    var auto by remember { mutableStateOf(prefs.autoSwitchRoutes) }
    var gain by remember { mutableStateOf(prefs.minGainMinutes.toFloat()) }
    var interval by remember { mutableStateOf(prefs.alternativesIntervalSec.toFloat()) }
    var voice by remember { mutableStateOf(prefs.voiceEnabled) }
    var oneway by remember { mutableStateOf(prefs.showOnewayArrows) }
    var traffic by remember { mutableStateOf(prefs.showTraffic) }
    var limits by remember { mutableStateOf(prefs.showSpeedLimits) }
    var record by remember { mutableStateOf(prefs.recordTrips) }
    var northUp by remember { mutableStateOf(prefs.northUp) }
    var keepOn by remember { mutableStateOf(prefs.keepScreenOn) }
    var simulate by remember { mutableStateOf(prefs.simulateDriving) }
    var tomtom by remember { mutableStateOf(prefs.tomtomKey) }
    var osrm by remember { mutableStateOf(prefs.osrmBase) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp)
            .padding(top = 26.dp, bottom = 30.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.go(Screen.MAPA) }) {
                Icon(ManeuverIcons.back, contentDescription = "Volver")
            }
            Text("Ajustes", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        Section("Cambio de ruta")
        SwitchRow(
            title = "Cambio automático de ruta",
            subtitle = "Si está apagado (recomendado), la app solo avisa y tú decides si cambias.",
            checked = auto
        ) { auto = it; prefs.autoSwitchRoutes = it }

        SliderRow(
            title = "Avisar solo si ahorro al menos ${gain.toInt()} min",
            value = gain, range = 1f..15f, steps = 13
        ) { gain = it; prefs.minGainMinutes = it.toInt() }

        SliderRow(
            title = "Buscar alternativas cada ${interval.toInt()} s",
            value = interval, range = 30f..300f, steps = 8
        ) { interval = it; prefs.alternativesIntervalSec = it.toInt() }

        Section("Mapa y guía")
        SwitchRow("Voz en español", "Instrucciones habladas de cada maniobra.", voice) {
            voice = it; prefs.voiceEnabled = it; vm.controller.voice.enabled = it
        }
        SwitchRow("Flechas de sentido de las vías", "Dibuja el sentido de circulación sobre cada calle.", oneway) {
            oneway = it; prefs.showOnewayArrows = it
        }
        SwitchRow("Mostrar tráfico", "Colorea la ruta según la congestión.", traffic) {
            traffic = it; prefs.showTraffic = it
        }
        SwitchRow("Límites de velocidad", "Toma los límites de OpenStreetMap y avisa si te pasas.", limits) {
            limits = it; prefs.showSpeedLimits = it
        }
        SwitchRow("Mapa siempre al norte", "Si está apagado, el mapa gira con el vehículo.", northUp) {
            northUp = it; prefs.northUp = it
        }
        SwitchRow("Mantener pantalla encendida", "Mientras navegas.", keepOn) {
            keepOn = it; prefs.keepScreenOn = it
        }

        Section("Historial")
        SwitchRow("Grabar cada trayecto", "Kilómetros, tiempo, paradas y trazado, solo en este teléfono.", record) {
            record = it; prefs.recordTrips = it
        }

        Section("Avanzado")
        SwitchRow(
            "Modo simulación",
            "Recorre la ruta sin moverte, para probar la app en casa.",
            simulate
        ) { simulate = it; prefs.simulateDriving = it }

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = tomtom,
            onValueChange = { tomtom = it; prefs.tomtomKey = it.trim() },
            label = { Text("Clave de TomTom (tráfico en vivo, opcional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Sin clave, el tráfico que ves es una estimación calculada en el teléfono.",
            fontSize = 11.sp, color = GrisTexto, modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = osrm,
            onValueChange = { osrm = it; prefs.osrmBase = it.trim() },
            label = { Text("Servidor de rutas (OSRM)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Por defecto usa el servidor público de demostración de OSRM. Para uso intenso conviene montar uno propio.",
            fontSize = 11.sp, color = GrisTexto, modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(20.dp))
        Text(
            "Mapas © OpenStreetMap contributors · Teselas de OpenFreeMap · Ruteo OSRM · Búsqueda Nominatim",
            fontSize = 11.sp,
            color = GrisTexto
        )
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(18.dp))
    Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    HorizontalDivider(Modifier.padding(vertical = 6.dp))
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 11.sp, color = GrisTexto)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(title, fontWeight = FontWeight.Medium)
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            steps = steps
        )
    }
}
