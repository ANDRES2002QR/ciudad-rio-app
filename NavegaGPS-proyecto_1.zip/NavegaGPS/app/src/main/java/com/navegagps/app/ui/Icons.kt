package com.navegagps.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.ForkLeft
import androidx.compose.material.icons.filled.ForkRight
import androidx.compose.material.icons.filled.RampLeft
import androidx.compose.material.icons.filled.RampRight
import androidx.compose.material.icons.filled.RoundaboutLeft
import androidx.compose.material.icons.filled.RoundaboutRight
import androidx.compose.material.icons.filled.Straight
import androidx.compose.material.icons.filled.TurnLeft
import androidx.compose.material.icons.filled.TurnRight
import androidx.compose.material.icons.filled.TurnSharpLeft
import androidx.compose.material.icons.filled.TurnSharpRight
import androidx.compose.material.icons.filled.TurnSlightLeft
import androidx.compose.material.icons.filled.TurnSlightRight
import androidx.compose.material.icons.filled.UTurnLeft
import androidx.compose.ui.graphics.vector.ImageVector

/** Traduce la clave lógica de una maniobra al icono que se pinta. */
object ManeuverIcons {
    fun of(key: String): ImageVector = when (key) {
        "turn_left" -> Icons.Filled.TurnLeft
        "turn_right" -> Icons.Filled.TurnRight
        "slight_left" -> Icons.Filled.TurnSlightLeft
        "slight_right" -> Icons.Filled.TurnSlightRight
        "sharp_left" -> Icons.Filled.TurnSharpLeft
        "sharp_right" -> Icons.Filled.TurnSharpRight
        "uturn" -> Icons.Filled.UTurnLeft
        "roundabout_left" -> Icons.Filled.RoundaboutLeft
        "roundabout_right" -> Icons.Filled.RoundaboutRight
        "merge" -> Icons.Filled.TurnSlightRight
        "ramp_left" -> Icons.Filled.RampLeft
        "ramp_right" -> Icons.Filled.RampRight
        "fork_left" -> Icons.Filled.ForkLeft
        "fork_right" -> Icons.Filled.ForkRight
        "flag" -> Icons.Filled.Flag
        "straight" -> Icons.Filled.Straight
        else -> Icons.Filled.ArrowUpward
    }

    val back: ImageVector = Icons.AutoMirrored.Filled.ArrowBack
}
