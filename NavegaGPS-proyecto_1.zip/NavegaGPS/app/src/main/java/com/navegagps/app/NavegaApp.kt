package com.navegagps.app

import android.app.Application
import com.navegagps.app.core.Prefs
import com.navegagps.app.data.TripRepository
import com.navegagps.app.nav.NavigationController
import org.maplibre.android.MapLibre

class NavegaApp : Application() {

    lateinit var prefs: Prefs
        private set
    lateinit var repository: TripRepository
        private set
    lateinit var controller: NavigationController
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        // MapLibre no necesita token; se pasa null.
        MapLibre.getInstance(this)
        prefs = Prefs(this)
        repository = TripRepository(this)
        controller = NavigationController(this, prefs, repository)
    }

    companion object {
        lateinit var instance: NavegaApp
            private set
    }
}
