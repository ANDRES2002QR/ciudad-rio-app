package com.navegagps.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navegagps.app.nav.Place as NavPlace

@Composable
fun SearchScreen(vm: MainViewModel) {
    val ui by vm.ui.collectAsState()

    Scaffold { inner ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .padding(horizontal = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.go(Screen.MAPA) }) {
                    Icon(ManeuverIcons.back, contentDescription = "Volver")
                }
                Text("Elegir destino", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            OutlinedTextField(
                value = ui.query,
                onValueChange = { vm.onQueryChange(it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Dirección, lugar o coordenadas") },
                singleLine = true,
                trailingIcon = {
                    if (ui.query.isNotEmpty()) {
                        IconButton(onClick = { vm.onQueryChange("") }) {
                            Icon(Icons.Filled.Close, contentDescription = "Limpiar")
                        }
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            if (ui.searching) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.Center
                ) { CircularProgressIndicator(modifier = Modifier.size(28.dp)) }
            }

            LazyColumn(Modifier.fillMaxSize()) {
                if (ui.results.isNotEmpty()) {
                    item { SectionTitle("Resultados") }
                    items(ui.results) { place ->
                        PlaceRow(place, Icons.Filled.Place, onClick = { vm.chooseDestination(place) },
                            onStar = { vm.saveFavorite(place) })
                        HorizontalDivider()
                    }
                }
                if (ui.favorites.isNotEmpty()) {
                    item { SectionTitle("Favoritos") }
                    items(ui.favorites) { place ->
                        PlaceRow(place, Icons.Filled.Star, onClick = { vm.chooseDestination(place) },
                            onDelete = { vm.deleteFavorite(place) })
                        HorizontalDivider()
                    }
                }
                if (ui.recents.isNotEmpty()) {
                    item { SectionTitle("Recientes") }
                    items(ui.recents) { place ->
                        PlaceRow(place, Icons.Filled.History, onClick = { vm.chooseDestination(place) },
                            onStar = { vm.saveFavorite(place) })
                        HorizontalDivider()
                    }
                }
                if (ui.results.isEmpty() && ui.favorites.isEmpty() && ui.recents.isEmpty()) {
                    item {
                        Text(
                            "Escribe al menos 3 letras para buscar. También puedes mantener pulsado un punto del mapa para fijar ahí el destino.",
                            color = GrisTexto,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)
    )
}

@Composable
private fun PlaceRow(
    place: NavPlace,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    onStar: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = GrisTexto)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(place.name, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(place.address, fontSize = 12.sp, color = GrisTexto, maxLines = 2)
        }
        if (onStar != null) {
            IconButton(onClick = onStar) {
                Icon(Icons.Filled.Star, contentDescription = "Guardar", tint = Ambar)
            }
        }
        if (onDelete != null) {
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Eliminar", tint = GrisTexto)
            }
        }
    }
}
