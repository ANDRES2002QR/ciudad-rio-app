package com.navegagps.app.map

import android.graphics.Color
import android.graphics.PointF
import com.navegagps.app.core.GeoPoint
import com.navegagps.app.nav.Congestion
import com.navegagps.app.nav.NavRoute
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

/**
 * Todo lo que se dibuja encima del mapa: ruta activa, alternativas seleccionables,
 * tráfico por tramos, flechas de sentido de circulación y la posición del vehículo.
 */
class MapRenderer(private val map: MapLibreMap) {

    companion object {
        const val STYLE_DAY = "https://tiles.openfreemap.org/styles/liberty"
        const val STYLE_NIGHT = "https://tiles.openfreemap.org/styles/positron"

        // fuentes
        private const val SRC_ROUTE = "src-route"
        private const val SRC_TRAFFIC = "src-traffic"
        private const val SRC_ALTS = "src-alts"
        private const val SRC_MARKERS = "src-markers"
        private const val SRC_PUCK = "src-puck"
        private const val SRC_TRACK = "src-track"

        // capas
        const val LAYER_ALT_LINE = "layer-alt-line"
        private const val LAYER_ROUTE_CASING = "layer-route-casing"
        private const val LAYER_ROUTE = "layer-route"
        private const val LAYER_TRAFFIC = "layer-traffic"
        private const val LAYER_ALT_LABEL = "layer-alt-label"
        private const val LAYER_ONEWAY = "layer-oneway"
        private const val LAYER_MARKERS = "layer-markers"
        private const val LAYER_PUCK = "layer-puck"
        private const val LAYER_TRACK = "layer-track"

        // la fuente de teselas vectoriales de OpenFreeMap / OpenMapTiles
        private const val VECTOR_SOURCE = "openmaptiles"
        private const val VECTOR_ROADS_LAYER = "transportation"

        private val FONT = arrayOf("Noto Sans Regular", "Open Sans Regular", "Arial Unicode MS Regular")
    }

    private var style: Style? = null
    var onewayVisible: Boolean = true
        set(value) {
            field = value
            style?.getLayer(LAYER_ONEWAY)?.setProperties(
                PropertyFactory.visibility(if (value) Property.VISIBLE else Property.NONE)
            )
        }

    var trafficVisible: Boolean = true
        set(value) {
            field = value
            style?.getLayer(LAYER_TRAFFIC)?.setProperties(
                PropertyFactory.visibility(if (value) Property.VISIBLE else Property.NONE)
            )
        }

    /** Crea fuentes y capas una sola vez, cuando el estilo termina de cargar. */
    fun attach(style: Style) {
        this.style = style

        style.addImage(MapAssets.ONEWAY_ARROW, MapAssets.onewayArrow())
        style.addImage(MapAssets.PUCK, MapAssets.puck())
        style.addImage(MapAssets.DESTINATION, MapAssets.destinationPin())
        style.addImage(MapAssets.WAYPOINT, MapAssets.waypointPin())

        style.addSource(GeoJsonSource(SRC_ROUTE, FeatureCollection.fromFeatures(emptyList())))
        style.addSource(GeoJsonSource(SRC_TRAFFIC, FeatureCollection.fromFeatures(emptyList())))
        style.addSource(GeoJsonSource(SRC_ALTS, FeatureCollection.fromFeatures(emptyList())))
        style.addSource(GeoJsonSource(SRC_MARKERS, FeatureCollection.fromFeatures(emptyList())))
        style.addSource(GeoJsonSource(SRC_PUCK, FeatureCollection.fromFeatures(emptyList())))
        style.addSource(GeoJsonSource(SRC_TRACK, FeatureCollection.fromFeatures(emptyList())))

        // --- flechas de sentido de circulación sobre cada calle ---
        if (style.getSource(VECTOR_SOURCE) != null) {
            val oneway = SymbolLayer(LAYER_ONEWAY, VECTOR_SOURCE)
            oneway.setSourceLayer(VECTOR_ROADS_LAYER)
            oneway.minZoom = 13.5f
            oneway.setFilter(
                Expression.any(
                    Expression.eq(Expression.get("oneway"), Expression.literal(1)),
                    Expression.eq(Expression.get("oneway"), Expression.literal(-1))
                )
            )
            oneway.setProperties(
                PropertyFactory.iconImage(MapAssets.ONEWAY_ARROW),
                PropertyFactory.symbolPlacement(Property.SYMBOL_PLACEMENT_LINE),
                PropertyFactory.symbolSpacing(110f),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconRotate(
                    Expression.switchCase(
                        Expression.eq(Expression.get("oneway"), Expression.literal(-1)),
                        Expression.literal(180f),
                        Expression.literal(0f)
                    )
                ),
                PropertyFactory.iconSize(
                    Expression.interpolate(
                        Expression.linear(), Expression.zoom(),
                        Expression.stop(13.5f, 0.35f),
                        Expression.stop(16f, 0.6f),
                        Expression.stop(19f, 0.9f)
                    )
                ),
                PropertyFactory.iconOpacity(0.95f),
                PropertyFactory.visibility(if (onewayVisible) Property.VISIBLE else Property.NONE)
            )
            style.addLayer(oneway)
        }

        // --- trayecto grabado (historial) ---
        style.addLayer(
            LineLayer(LAYER_TRACK, SRC_TRACK).withProperties(
                PropertyFactory.lineColor(Color.parseColor("#7C3AED")),
                PropertyFactory.lineWidth(5f),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
                PropertyFactory.lineOpacity(0.9f)
            )
        )

        // --- rutas alternativas (se pueden tocar para cambiar) ---
        style.addLayer(
            LineLayer(LAYER_ALT_LINE, SRC_ALTS).withProperties(
                PropertyFactory.lineColor(Color.parseColor("#94A3B8")),
                PropertyFactory.lineWidth(
                    Expression.interpolate(
                        Expression.linear(), Expression.zoom(),
                        Expression.stop(10f, 5f), Expression.stop(16f, 9f)
                    )
                ),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
                PropertyFactory.lineOpacity(0.85f),
                PropertyFactory.lineDasharray(arrayOf(2.2f, 1.4f))
            )
        )

        // --- ruta activa ---
        style.addLayer(
            LineLayer(LAYER_ROUTE_CASING, SRC_ROUTE).withProperties(
                PropertyFactory.lineColor(Color.parseColor("#0B3D2E")),
                PropertyFactory.lineWidth(
                    Expression.interpolate(
                        Expression.linear(), Expression.zoom(),
                        Expression.stop(10f, 9f), Expression.stop(16f, 16f)
                    )
                ),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
            )
        )
        style.addLayer(
            LineLayer(LAYER_ROUTE, SRC_ROUTE).withProperties(
                PropertyFactory.lineColor(Color.parseColor("#22C55E")),
                PropertyFactory.lineWidth(
                    Expression.interpolate(
                        Expression.linear(), Expression.zoom(),
                        Expression.stop(10f, 6f), Expression.stop(16f, 11f)
                    )
                ),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND)
            )
        )

        // --- tráfico por tramos, encima de la ruta ---
        style.addLayer(
            LineLayer(LAYER_TRAFFIC, SRC_TRAFFIC).withProperties(
                PropertyFactory.lineColor(
                    Expression.match(
                        Expression.get("level"),
                        Expression.literal("#22C55E"),
                        Expression.stop("MODERADO", Expression.literal("#FACC15")),
                        Expression.stop("LENTO", Expression.literal("#F97316")),
                        Expression.stop("DETENIDO", Expression.literal("#DC2626"))
                    )
                ),
                PropertyFactory.lineWidth(
                    Expression.interpolate(
                        Expression.linear(), Expression.zoom(),
                        Expression.stop(10f, 6f), Expression.stop(16f, 11f)
                    )
                ),
                PropertyFactory.lineCap(Property.LINE_CAP_ROUND),
                PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
                PropertyFactory.visibility(if (trafficVisible) Property.VISIBLE else Property.NONE)
            )
        )

        // --- etiqueta con el tiempo de cada alternativa ---
        style.addLayer(
            SymbolLayer(LAYER_ALT_LABEL, SRC_ALTS).withProperties(
                PropertyFactory.textField(Expression.get("label")),
                PropertyFactory.textFont(FONT),
                PropertyFactory.textSize(13f),
                PropertyFactory.textColor(Color.parseColor("#0F172A")),
                PropertyFactory.textHaloColor(Color.WHITE),
                PropertyFactory.textHaloWidth(2f),
                PropertyFactory.symbolPlacement(Property.SYMBOL_PLACEMENT_LINE_CENTER),
                PropertyFactory.textAllowOverlap(false),
                PropertyFactory.textIgnorePlacement(false)
            )
        )

        // --- marcadores de destino ---
        style.addLayer(
            SymbolLayer(LAYER_MARKERS, SRC_MARKERS).withProperties(
                PropertyFactory.iconImage(Expression.get("icon")),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconAnchor(Property.ICON_ANCHOR_BOTTOM),
                PropertyFactory.iconSize(0.85f)
            )
        )

        // --- posición del vehículo ---
        style.addLayer(
            SymbolLayer(LAYER_PUCK, SRC_PUCK).withProperties(
                PropertyFactory.iconImage(MapAssets.PUCK),
                PropertyFactory.iconAllowOverlap(true),
                PropertyFactory.iconIgnorePlacement(true),
                PropertyFactory.iconRotationAlignment(Property.ICON_ROTATION_ALIGNMENT_MAP),
                PropertyFactory.iconRotate(Expression.get("bearing")),
                PropertyFactory.iconSize(0.55f)
            )
        )
    }

    fun detach() {
        style = null
    }

    // --------------------------------------------------------------- contenidos

    fun setRoute(route: NavRoute?, showTraffic: Boolean) {
        val s = style ?: return
        val routeSrc = s.getSourceAs<GeoJsonSource>(SRC_ROUTE)
        val trafficSrc = s.getSourceAs<GeoJsonSource>(SRC_TRAFFIC)
        if (route == null || route.points.size < 2) {
            routeSrc?.setGeoJson(FeatureCollection.fromFeatures(emptyList()))
            trafficSrc?.setGeoJson(FeatureCollection.fromFeatures(emptyList()))
            return
        }
        routeSrc?.setGeoJson(Feature.fromGeometry(lineOf(route.points)))

        val features = ArrayList<Feature>()
        if (showTraffic) {
            for (seg in route.traffic) {
                if (seg.level == Congestion.FLUIDO || seg.level == Congestion.DESCONOCIDO) continue
                val from = seg.fromIndex.coerceIn(0, route.points.size - 1)
                val to = (seg.toIndex + 1).coerceIn(1, route.points.size)
                if (from >= to - 1) continue
                val slice = route.points.subList(from, to)
                if (slice.size < 2) continue
                val f = Feature.fromGeometry(lineOf(slice))
                f.addStringProperty("level", seg.level.name)
                features.add(f)
            }
        }
        trafficSrc?.setGeoJson(FeatureCollection.fromFeatures(features))
    }

    fun setAlternatives(routes: List<NavRoute>, labelBuilder: (NavRoute) -> String) {
        val s = style ?: return
        val src = s.getSourceAs<GeoJsonSource>(SRC_ALTS) ?: return
        val features = routes.filter { it.points.size >= 2 }.map { r ->
            val f = Feature.fromGeometry(lineOf(r.points))
            f.addStringProperty("routeId", r.id)
            f.addStringProperty("label", labelBuilder(r))
            f
        }
        src.setGeoJson(FeatureCollection.fromFeatures(features))
    }

    fun setMarkers(destination: GeoPoint?, waypoints: List<GeoPoint> = emptyList()) {
        val s = style ?: return
        val src = s.getSourceAs<GeoJsonSource>(SRC_MARKERS) ?: return
        val list = ArrayList<Feature>()
        waypoints.forEach { w ->
            val f = Feature.fromGeometry(Point.fromLngLat(w.lng, w.lat))
            f.addStringProperty("icon", MapAssets.WAYPOINT)
            list.add(f)
        }
        destination?.let {
            val f = Feature.fromGeometry(Point.fromLngLat(it.lng, it.lat))
            f.addStringProperty("icon", MapAssets.DESTINATION)
            list.add(f)
        }
        src.setGeoJson(FeatureCollection.fromFeatures(list))
    }

    fun setPuck(point: GeoPoint?, bearing: Float) {
        val s = style ?: return
        val src = s.getSourceAs<GeoJsonSource>(SRC_PUCK) ?: return
        if (point == null) {
            src.setGeoJson(FeatureCollection.fromFeatures(emptyList()))
            return
        }
        val f = Feature.fromGeometry(Point.fromLngLat(point.lng, point.lat))
        f.addNumberProperty("bearing", bearing)
        src.setGeoJson(f)
    }

    fun setTrack(points: List<GeoPoint>) {
        val s = style ?: return
        val src = s.getSourceAs<GeoJsonSource>(SRC_TRACK) ?: return
        if (points.size < 2) {
            src.setGeoJson(FeatureCollection.fromFeatures(emptyList()))
        } else {
            src.setGeoJson(Feature.fromGeometry(lineOf(points)))
        }
    }

    // ----------------------------------------------------------------- cámara

    fun follow(point: GeoPoint, bearing: Float, northUp: Boolean, zoom: Double = 17.2) {
        val pos = CameraPosition.Builder()
            .target(LatLng(point.lat, point.lng))
            .zoom(zoom)
            .bearing(if (northUp) 0.0 else bearing.toDouble())
            .tilt(if (northUp) 0.0 else 50.0)
            .build()
        map.animateCamera(CameraUpdateFactory.newCameraPosition(pos), 900)
    }

    fun center(point: GeoPoint, zoom: Double = 16.0) {
        map.animateCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder().target(LatLng(point.lat, point.lng)).zoom(zoom).tilt(0.0).bearing(0.0).build()
            ), 700
        )
    }

    fun fit(points: List<GeoPoint>, paddingPx: Int = 120, extraBottomPx: Int = 320) {
        if (points.size < 2) return
        val builder = LatLngBounds.Builder()
        val step = maxOf(1, points.size / 400)
        var i = 0
        while (i < points.size) {
            builder.include(LatLng(points[i].lat, points[i].lng))
            i += step
        }
        builder.include(LatLng(points.last().lat, points.last().lng))
        runCatching {
            map.animateCamera(
                CameraUpdateFactory.newLatLngBounds(
                    builder.build(), paddingPx, paddingPx, paddingPx, extraBottomPx
                ), 800
            )
        }
    }

    /** Devuelve el id de la ruta alternativa tocada, si la hubo. */
    fun alternativeAt(screen: PointF): String? {
        val features = map.queryRenderedFeatures(screen, LAYER_ALT_LINE)
        return features.firstOrNull()?.getStringProperty("routeId")
    }

    private fun lineOf(points: List<GeoPoint>): LineString =
        LineString.fromLngLats(points.map { Point.fromLngLat(it.lng, it.lat) })
}
