# NavegaGPS

Aplicación de navegación GPS para Android, escrita en Kotlin + Jetpack Compose, con
mapas vectoriales libres (MapLibre + OpenStreetMap). **No necesita ninguna clave de API
para funcionar.**

---

## 1. Qué hace

| Lo que pediste | Cómo está resuelto |
|---|---|
| Mapa tipo Google Maps, pero distinto | Mapa vectorial MapLibre con teselas de OpenFreeMap (OSM), tema claro y oscuro automáticos, rotación e inclinación 3D al navegar. |
| **Poder cambiar entre rutas posibles** | Antes de arrancar se calculan hasta 3 rutas; se ven todas dibujadas y se elige una tocándola en el mapa o en la lista. |
| **Cambiar de ruta en movimiento, solo si quiero** | Cada cierto tiempo (configurable, 90 s por defecto) la app busca rutas nuevas desde donde vas. Si encuentra una mejor, **avisa** con un cartel: *«Cambiar ruta» / «Seguir igual»*. **Nunca cambia sola**, salvo que enciendas «Cambio automático» en Ajustes. Además, el botón «Rutas» abre en cualquier momento la lista de alternativas disponibles y puedes saltar a otra con un toque. |
| **Señalización del sentido de las calles** | Capa de flechas azules dibujadas sobre cada vía de sentido único, leídas del atributo `oneway` de OpenStreetMap, con densidad y tamaño según el zoom. |
| Indicaciones detalladas | Tarjeta de maniobra con icono, distancia y calle; **guía de carriles** (los carriles válidos en verde) sacada de los datos de intersección del motor de ruteo; límites de velocidad de OSM con aviso al excederlos; **voz en español** (TTS). |
| Tráfico vehicular | Ruta coloreada por congestión (verde / amarillo / naranja / rojo). Sin clave es una **estimación** honesta (velocidad de cada tramo vs. límite real + factor de hora pico) y así se rotula. Si pegas una clave gratuita de TomTom en Ajustes, pasa a **tráfico en vivo**. |
| Ubicación precisa | Fused Location a 1 Hz en alta precisión, filtro de Kalman, descarte de saltos imposibles y *map-matching* que pega el vehículo al trazado de la ruta. Respaldo a GPS puro si no hay Play Services. |
| Iniciador de destino | Buscador de direcciones (Nominatim), favoritos, recientes, mantener pulsado el mapa, o abrir un enlace `geo:` desde otra app. Siempre hay una pantalla de **vista previa** con las rutas y el botón **INICIAR RUTA**: nada arranca solo. |
| Historial de trayectos | Base SQLite local: kilómetros, tiempo total, tiempo en movimiento, tiempo detenido, velocidad media y máxima, **paradas** (más de 45 s parado) y el trazado completo dibujado en el mapa. Exportación a GPX y CSV. Todo se queda en el teléfono. |

Extras incluidos: servicio en primer plano (sigue navegando con la pantalla apagada),
grabación de recorridos sin destino, modo simulación para probar la app sin moverte,
y servidor de ruteo configurable por si montas el tuyo.

---

## 2. Cómo obtener el APK

El proyecto está completo y listo para compilar. Tres caminos, de más fácil a más técnico.

### Opción A — GitHub compila el APK por ti (recomendada, sin instalar nada)

1. Crea un repositorio nuevo en GitHub (puede ser privado).
2. Sube el contenido de esta carpeta (botón *Add file → Upload files*, arrastra todo, o por `git`).
3. Ve a la pestaña **Actions**. El flujo «Compilar APK» arranca solo con la subida.
4. Cuando termine (5–8 min), entra a la ejecución y descarga el artefacto **NavegaGPS-APK**.
   Dentro está `app-debug.apk`.

Por `git`, desde una carpeta con el proyecto:

```bash
git init
git add .
git commit -m "NavegaGPS"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

### Opción B — Android Studio

1. Instala [Android Studio](https://developer.android.com/studio).
2. *File → Open* y elige esta carpeta. Espera a que sincronice Gradle (descarga dependencias).
3. *Build → Build Bundle(s)/APK(s) → Build APK(s)*.
4. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción C — Línea de comandos

Con JDK 17 y el SDK de Android instalados (`ANDROID_HOME` configurado):

```bash
./gradlew assembleDebug
```

---

## 3. Instalar en el teléfono

1. Pasa el `.apk` al teléfono (cable, Drive, WhatsApp a ti mismo…).
2. Ábrelo. Android pedirá permitir «Instalar apps desconocidas» para esa aplicación: acepta.
3. Al abrir NavegaGPS, concede **Ubicación → Permitir mientras se usa la app** (mejor: *Ubicación precisa* activada) y **Notificaciones**.
4. Para que siga navegando con la pantalla apagada, en los ajustes de Android quita la
   optimización de batería para NavegaGPS.

Requisitos: Android 7.0 (API 24) o superior.

---

## 4. Cómo se usa

- **Fijar destino**: toca la barra superior y busca, o mantén pulsado un punto del mapa.
- **Elegir ruta**: en la vista previa aparecen las rutas con su tiempo y distancia.
  Tócalas para comparar; el color del punto indica la congestión estimada del peor tramo.
- **Arrancar**: botón verde **INICIAR RUTA**.
- **Cambiar de ruta en marcha**: botón **Rutas** en la barra inferior, o toca directamente
  una línea gris punteada en el mapa. También puedes pulsar el botón de recarga (↻) para
  pedir alternativas nuevas en ese instante.
- **Si aparece el cartel amarillo**: «Cambiar ruta» aplica la nueva; «Seguir igual» la descarta
  y continúas por donde ibas.
- **Historial**: icono del reloj arriba, o el botón «Historial». Dentro de cada trayecto
  tienes el mapa del recorrido, los totales, la lista de paradas y la exportación GPX/CSV.

---

## 5. Ajustes que vale la pena tocar

| Ajuste | Para qué |
|---|---|
| Cambio automático de ruta | Apagado por defecto. Enciéndelo solo si quieres que la app cambie sin preguntar. |
| Ahorro mínimo (min) | Umbral para que una alternativa merezca el aviso. |
| Buscar alternativas cada (s) | Frecuencia con que se consulta el servidor mientras conduces. Súbelo si quieres gastar menos datos. |
| Clave de TomTom | Opcional. Con ella el tráfico deja de ser estimado y pasa a ser real. Se saca gratis en developer.tomtom.com. |
| Servidor de rutas (OSRM) | Por defecto el servidor público de demostración. Para uso diario intenso conviene montar uno propio (`project-osrm.org`) y pegar aquí su dirección. |
| Modo simulación | Recorre la ruta sin moverte. Ideal para probar la app sentado en casa. |

---

## 6. Estructura del código

```
app/src/main/java/com/navegagps/app/
├─ core/        Geo.kt (geometría, polilíneas, map-matching), Format.kt, Prefs.kt
├─ net/         OsrmClient (rutas + alternativas + carriles)
│               NominatimClient (búsqueda), OverpassClient (límites de velocidad)
│               TrafficProvider (estimado / TomTom en vivo), Http
├─ nav/         RouteModel, Instructions (español), Voice (TTS),
│               NavigationController (el cerebro: estado, progreso, alternativas, grabación)
├─ location/    LocationEngine (fused + Kalman), NavigationService (primer plano)
├─ data/        TripDb (SQLite), TripRepository (historial, favoritos, GPX/CSV)
├─ map/         MapRenderer (capas de ruta, tráfico, flechas de sentido), MapAssets
└─ ui/          MapScreen, SearchScreen, HistoryScreen, TripDetailScreen,
                SettingsScreen, NavComponents, MainViewModel, Theme
```

---

## 7. Servicios que usa (y sus límites)

- **OpenFreeMap** — teselas vectoriales del mapa. Gratis, sin clave.
- **OSRM demo** (`router.project-osrm.org`) — cálculo de rutas. Gratis, pero es un servidor
  de demostración: puede ir lento o limitar peticiones en horas altas. Cambiable en Ajustes.
- **Nominatim** — búsqueda de direcciones. Tiene una política de uso justo (1 consulta/segundo);
  la app ya aplica antirrebote y envía un User-Agent identificable.
- **Overpass API** — límites de velocidad y atributos de las vías. Se consulta una vez por ruta.
- **TomTom Traffic** — opcional, solo si pones tu clave.

Todos los datos de mapa provienen de **OpenStreetMap contributors** (licencia ODbL); si publicas
la app, mantén ese crédito visible (ya aparece en la pantalla de Ajustes y en la atribución del mapa).

---

## 8. Notas honestas

- El **tráfico sin clave de TomTom es una estimación**, no un dato en vivo: se calcula con la
  velocidad que el motor de ruteo asigna a cada tramo, el límite real de la vía y un factor de
  hora pico. Sirve para comparar rutas entre sí; no equivale al tráfico de Google.
- El APK de `release` viene firmado con la clave de depuración para que puedas instalarlo sin
  configurar nada. Si algún día quieres publicarlo en Play Store, hay que generar una clave
  propia y configurar `signingConfigs` en `app/build.gradle.kts`.
- La versión de MapLibre está fijada en `11.5.1`. Si Gradle no la encontrara, cambia esa línea
  de `app/build.gradle.kts` por otra versión 11.x publicada en Maven Central.
